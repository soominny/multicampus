
import time
from selenium import webdriver
import pandas as pd


url = "https://play.google.com/store/apps/details?id=com.shinhan.sbanking&showAllReviews=true"  #접속하고자하는 url
driverPath = "/Users/parksoomin/Desktop/chromedriver" # driver file path
driver = webdriver.Chrome(driverPath) # Open Chrome
driver.get(url)# Enter the url

reviews = driver.find_elements_by_xpath("//span[@jsname='bN97Pc']")
dates = driver.find_elements_by_xpath("//span[@class='p2TkOb']")
likes = driver.find_elements_by_xpath("//div[@aria-label='이 리뷰가 유용하다는 평가를 받은 횟수입니다.']")
stars = driver.find_elements_by_xpath("//span[@class='nt2C1d']/div[@class='pf5lIe']/div[@role='img']")
#print(len(reviews))

res_dict = []
for i in range(len(reviews)):
    res_dict.append({
        'DATE' : dates[i].text,
        'STAR' : stars[i].get_attribute('aria-label'),
        'LIKE' : likes[i].text,
        'REVIEW' : reviews[i].text })
res_df = pd.DataFrame(res_dict)
print(res_df)
