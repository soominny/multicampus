#!/usr/bin/env python
# coding: utf-8

# In[19]:



import time
from bs4 import BeautifulSoup
from selenium import webdriver

url = "https://play.google.com/store/apps/details?id=com.shinhan.sbanking&showAllReviews=true"  # 접속하고자하는 url
driverPath = "/Users/parksoomin/Desktop/chromedriver"  # driver file path
driver = webdriver.Chrome(driverPath)  # Open Chrome
driver.get(url)  # Enter the url
## driver.implicitly_wait(3) # 3초 기다림
#
# #1
# SCROLL_PAUSE_TIME = 0.5
# while (True):
#
#     # Scroll down to bottom
#     for i in range(1,5):
#       driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
#       # Wait to load page
#       time.sleep(SCROLL_PAUSE_TIME)
#     try:
#         # 버튼찾기
#         element = driver.find_element_by_xpath('/html/body/div[1]/div[4]/c-wiz/div/div[2]/div/div/main/div/div[1]/div[2]/div[2]/div/span/span')
#
#         if (element is not None):
#             print("complete")
#             element.click()
#
#             new_height = driver.execute_script("return document.body.scrollHeight")
#             if new_height == last_height:
#                 break
#             last_height = new_height
#
#     except Exception:
#         continue



# 2번
# SCROLL_PAUSE_TIME = 1.5
# last_height = driver.execute_script("return document.body.scrollHeight")
# while True:
#     # (1) 4번의  스크롤링
#     for i in range(1,5):
#         driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
#         time.sleep(SCROLL_PAUSE_TIME)
#
#     # (2) 더보기 클릭
#     element = driver.find_element_by_xpath('//*[@id="fcxH9b"]/div[4]/c-wiz/div/div[2]/div/div/main/div/div[1]/div[2]/div[2]/div/span/span')
#     element.click()
#     print('More')
#
#     # (3) 종료 조건
#     new_height = driver.execute_script("return document.body.scrollHeight")
#     if new_height == last_height:
#         break
#     last_height = new_height


res_dict = []
for i in range(len(reviews)):
    res_dict.append({
        'DATE' : dates[i].text,
        'STAR' : stars[i].get_attribute('aria-label'),
        'LIKE' : likes[i].text,
        'REVIEW' : reviews[i].text })
res_df = pd.DataFrame(res_dict)
res_df






# 1.리뷰데이터

reviews = driver.find_elements_by_xpath("//span[@jsname='bN97Pc']")
print(len(reviews))
# (review)

# reviews = driver.find_elements_by_xpath("//span[@jsname='bN97Pc']")
# len(reviews)


# 2.날짜데이터
date = driver.find_element_by_xpath("//span[@class='p2TkOb']")
date.text

# 3.좋아요 수 데이터
like = driver.find_element_by_xpath("//div[@aria-label='이 리뷰가 유용하다는 평가를 받은 횟수입니다.']")
like.text

# 4.별점데이터

star = driver.find_element_by_xpath("//span[@class='nt2C1d']/div[@class='pf5lIe']/div[@role='img']")
star.get_attribute('aria-label')


