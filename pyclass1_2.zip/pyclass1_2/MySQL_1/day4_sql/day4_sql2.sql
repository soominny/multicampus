
-- 외래키 추가하기 
-- ALTER TABLE 테이블명
-- 	ADD CONSTRAINT 테이블명_ibfk_1
--  FOREIGN KEY (외래키필드명)
--  REFERENCES 참조테이블명(참조테이블의 외래키필드명);

-- ALTER TABLE buyTbl
-- 	ADD CONSTRAINT buyTbl_ibfk_1
-- 	FOREIGN KEY (userID)
-- 	REFERENCES userTbl(userID);
    
USE sqldb;	
-- usertbl => usertbl_a
-- userId(PK)

-- buytbl => buytbl_a
-- num(PK) 
-- userId(FK) 

CREATE TABLE usertbl_a (
	SELECT * FROM usertbl
);     
    
CREATE TABLE buytbl_a (
	SELECT * FROM buytbl
);      
    
DESC usertbl_a;    
DESC buytbl_a;    


-- usertbl_a 테이블에서 userID 필드를 기본키로 설정 
--  ALTER TABLE 테이블명
-- 		ADD CONSTRAINT PK_테이블명_기본키필드명
--  	PRIMARY KEY (기본키필드명); 

ALTER TABLE usertbl_a
	ADD CONSTRAINT PK_usertbl_a_userId
	PRIMARY KEY (userId); 

DESC usertbl_a;

-- buyTbl_a 테이블에서 num 필드를 기본키로 설정 
ALTER TABLE buyTbl_a
	ADD CONSTRAINT PK_buyTbl_a_num
	PRIMARY KEY (num); 

DESC buyTbl_a;

-- buyTbl_a 테이블에서 userID 필드를 외래키로 설정 
ALTER TABLE buyTbl_a
	ADD CONSTRAINT buyTbl_a_ibfk_1
	FOREIGN KEY (userID)
	REFERENCES userTbl_a(userID);    

DESC buyTbl_a;

--  외래키 삭제하기 
-- ALTER TABLE 테이블명 
-- 		DROP FOREIGN KEY 외래키명; 

-- 외래키명은 [SCHEMAS] 테이블 정보에서 확인 
-- 삭제 결과는 [SCHEMAS] 테이블에서 Foreign Keys 에서 확인 
ALTER TABLE buyTbl_a
		DROP FOREIGN KEY buyTbl_a_ibfk_1; 

-- 테이블 관리 퀴즈 
-- movieTbl :  영화목록(기본키)  
-- memberTbl : 회원목록(기본키) 
-- rentTbl : 대여목록(기본키, 외래키1-movieTbl, 외래키2-memberTbl) 

--  퀴즈1
--   다음과 같은 형태로  movieTbl 테이블을 생성하여라. 
--   movieNum int  -- 번호(기본키, 자동증감, 필수 속성) 
--   movieName varchar(30) -- 무비명(필수 속성) 
--   kind varchar(30) -- 장르명(필수 속성) 
--   price int, -- 대여 가격(필수 속성) 
--   period int -- 대여 기간(필수 속성) 

--   1 토이스토리 애니메이션 3000 5 

USE sqldb;
CREATE TABLE movieTbl
(
	movieNum int PRIMARY KEY NOT NULL AUTO_INCREMENT, 
    movieName varchar(30) NOT NULL,
	kind varchar(30) NULL,
    price int NOT NULL,
    period int NOT NULL
 );
DESC movieTbl;




-- 퀴즈2. 퀴즈1의 movieTbl 테이블의 자료형에 맞추어 5개의 레코드를 삽입하여라.
-- 샘플 :  1 토이스토리 애니메이션 3000 5
INSERT INTO movieTbl 
		VALUES 
			(NULL, '토이스토리', '애니메이션', 3000, 5), 
            (NULL, '극한직업', '액션', 1000, 5),
            (NULL, '안녕 자두야', NULL, 1000, 8), 
            (NULL, '설국 열자', '액션', 3000, 1),
            (NULL, '엽기적인 그녀', '코메디', 1500, 5);

SELECT * FROM movieTbl;

--  퀴즈3 
--   다음과 같은 형태로  memberTbl 테이블을 생성하여라. 
--     userNum int  -- 번호(기본키, 자동증감, 필수 속성) 
--     name varchar(20)  -- 회원명
--     grade int  -- 회원 등급(필수 속성) 
--     tel varchar(15)  -- 연락처(필수 속성) 
--     address varchar(300) -- 주소(널 허용)
--     money int  -- 예치금(필수 속성) 

-- 1 박수찬 3  010-6666-9999  삼광빌라905호  10000

CREATE TABLE memberTbl
(
	userNum int PRIMARY KEY NOT NULL AUTO_INCREMENT, 
    name varchar(20) NOT NULL,
	grade int NOT NULL,
    tel varchar(15) NOT NULL,
    address varchar(300) NULL, 
    money int NOT NULL
 );
DESC memberTbl;



-- 퀴즈4.  퀴즈3의 memberTbl 테이블의 자료형에 맞추어 7개 이상 레코드를 삽입하여라. 
INSERT INTO memberTbl VALUES (null, '김유신', 1, '011-0123-4567','12-3번지 301호', 10000);
INSERT INTO memberTbl VALUES (null, '강감찬', 2, '018-0123-4567','대한빌라 102호', 5000);
INSERT INTO memberTbl VALUES (null, '유관순', 3, '017-0123-4567','금강빌라 801호', 8000);
INSERT INTO memberTbl VALUES (null, '이율곡', 1, '011-3333-4567','오성아파트 301호', 10000);
INSERT INTO memberTbl VALUES (null, '안중근', 2, '010-0123-2222','789-9090번지', 8000);
INSERT INTO memberTbl VALUES (null, '박지원', 3, '011-6666-4567','부곡 아파트 301호', 10000);
INSERT INTO memberTbl VALUES (null, '신숙주', 1, '017-0123-5555','오륙도 아파트 301호', 0);
INSERT INTO memberTbl VALUES (null, '김부식', 3, '018-0000-4567','한산 아파트 905호', 500);
INSERT INTO memberTbl VALUES (null, '홍길동', 2, '011-0123-5555','한강빌라 903호', 50000);
INSERT INTO memberTbl VALUES (null, '김유신', 1, '016-1234-4567','조선 APT 902호', 7000);

SELECT * FROM memberTbl;




--  퀴즈5 
--   다음과 같은 형태로  rentTbl 테이블을 생성하여라. 

--    rentNum int  -- 대여번호(PK)(기본키, 자동증감, 필수 속성)
--    userNum int -- 대여한 회원번호(FK) (필수 속성, memberTbl의 키 참조)
--    movieNum int  --대여한 비디오번호(FK) (필수 속성, movieTbl의 키 참조)

-- 1  1  1

create table rentTbl
(
    rentNum int PRIMARY KEY not null AUTO_INCREMENT, -- 대여번호(PK)
    userNum int not null, -- 대여한 회원번호(FK)
	movieNum int not null, -- 대여한 비디오번호(FK)
    FOREIGN KEY(userNum) REFERENCES memberTbl(userNum),
	FOREIGN KEY(movieNum) REFERENCES movieTbl(movieNum)
);

-- 퀴즈6.  퀴즈5의 rentTbl 테이블의 자료형에 맞추어 7개 이상 레코드를 삽입하여라. 
INSERT INTO rentTbl VALUES (NULL, 1, 1), (NULL, 2, 2), (NULL, 3, 4);
INSERT INTO rentTbl VALUES (NULL, 10, 5), (NULL, 9, 5), (NULL, 5, 5);
INSERT INTO rentTbl VALUES (NULL, 9, 1), (NULL, 6, 2), (NULL, 3, 5);

SELECT * FROM rentTbl;



-- 퀴즈7.  3개의 테이블 (movietbl, rentTbl, memberTbl)을 이너조인하여라. 

    SELECT *  FROM renttbl R
	INNER JOIN membertbl M ON R.userNum = M.userNum
    INNER JOIN movietbl MV ON MV.movieNum = R.movieNum
    ORDER BY rentNum;
    

    SELECT rentNum, M.*, MV.*  FROM renttbl R
	INNER JOIN membertbl M ON R.userNum = M.userNum
    INNER JOIN movietbl MV ON MV.movieNum = R.movieNum
    ORDER BY rentNum;
    

-- 퀴즈8.  대여를 하지 않는 회원 목록을 출력하여라.
SELECT name FROM membertbl M
	LEFT OUTER JOIN renttbl R ON R.userNum = M.userNum
    WHERE rentNum is NULL;


-- 퀴즈9.  대여가 한번도 되지않은 영화 목록을 출력하여라.
SELECT name FROM membertbl M
	LEFT OUTER JOIN renttbl R ON R.userNum = M.userNum
    WHERE rentNum is NULL;


-- 퀴즈10.  회원별로 구매 횟수를 출력하여라.
SELECT name, count(R.userNum) FROM renttbl R
	INNER JOIN membertbl M ON R.userNum = M.userNum
    INNER JOIN movietbl MV ON MV.movieNum = R.movieNum
    GROUP BY R.userNum 
    ORDER BY count(R.userNum) DESC, name; 




    