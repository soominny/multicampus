# 퀴즈 : input() 문을 이용해서 값을 입력받아서
#       bookTbl 테이블의 레코드로 삽입하여 보세요
'''
레코드 삽입
----------
책이름 => ?
저자 => ?
페이지수 => ?
가격 => ?

----------
레코드 출력 (마지막에 삽입한 레코드가 첫번째 나오게한다)

?   ?   ?   ?   ?

'''

# Step1. 관련 모듈 임포트
import pymysql

# Step2 - mysql의 계정의 특정 데이타베이스에 접속해서 연결 객체(conn) 생성
conn = pymysql.connect( host = 'localhost',
                        port=3306, # mysql 포트
                        user='root', # 접속 계정
                        password = '12345678', # 루트계정의 본인 비번
                        db = 'sampleDb',  # 접속하고자 하는 데이타베이스명
                        charset = 'utf8' )


# Step3 - 커서(cursor) 객체 생성
# 객체명 = 연결객체(conn).cursor()
cursor = conn.cursor()

def makeDb():
    # Step4 - sql 명령을 실행
    # 커서(cursor)객체.execute(sql명령문)

    # 테이블 생성
    sql = ''' create table if not exists bookTbl
                    (
                        id int PRIMARY KEY not null AUTO_INCREMENT,
                        title text not null,
                        writer varchar(30) not null,
                        page int not null,
                        price int not null
                    ); '''
    cursor.execute(sql)

# 레코드 삽입함수 정의
def insertBook():
    print('-'*50)
    print('\t레코드 삽입')
    print('-' * 50)
    title = input('책이름 = > ')
    writer = input('저자 = > ')
    page = input('페이지수 = > ')
    price = input('가격 = > ')

    sql = ''' INSERT INTO bookTbl (title, writer, page, price)
                VALUES  (%s, %s, %s, %s)'''
    cursor.execute(sql, (title, writer, page, price))
    conn.commit()
    print('레코드가 삽입되었습니다.')



# 레코드 출력 함수 정의
def showBook():
    print('-'*50)
    print('\t레코드 출력')
    print('-' * 50)
    sql = 'SELECT * FROM bookTbl ORDER BY id DESC; '
    cursor.execute(sql)
    book_data = cursor.fetchall()
    for row in book_data:
        print(row)
        # for item in row:
        #     print(item)

# 레코드 삭제 함수 정의
#  레코드 삭제
#  DELETE FROM 테이블명  WHERE 컬럼명 = 값

# sql변수 = '''  DELETE FROM 테이블명
#               WHERE 컬럼명 = = %s; '''
# cursor.execute(sql변수, (값))

def deleteBook():
    print('-'*50)
    print('\t레코드 삭제')
    print('-' * 50)
    sql = 'DELETE FROM  bookTbl  WHERE id = %s'
    cursor.execute(sql, (1))
    conn.commit()
    print('레코드가 삭제되었습니다.')

# 레코드 수정함수
# 레코드 수정
#  UPDATE 테이블명 SET 컬럼명1 = 값1  WHERE 컬럼명2 = 값2

# sql변수 = '''  UPDATE 테이블명
#               SET 컬럼명1 = %s  WHERE 컬럼명2 = %s; '''
# cursor.execute(sql변수, (값1, ... ))

# 가격만 수정
def updateBook():
    print('-'*50)
    print('\t레코드 수정')
    print('-' * 50)
    id = input('id => ')
    price = input('가격 => ')
    sql = 'UPDATE bookTbl SET price=%s  WHERE id=%s;'
    cursor.execute(sql, (price, id))
    conn.commit()
    print('레코드가 수정되었습니다.')

showBook()
updateBook()
showBook()

# deleteBook()
# showBook()
# insertBook()


# Step6 - 데이타베이스 종료
conn.close()
