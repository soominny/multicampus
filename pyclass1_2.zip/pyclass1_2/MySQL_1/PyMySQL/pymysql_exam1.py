# MySQL 연동

#  pymysql 파이썬 모듈 확인
#  파이참에서 [File]-[Settings] 클릭후 [Project] 에서 pymysql 목록 확인
#  레퍼런스 사이트  https://github.com/PyMySQL/PyMySQL/
#  [Terminal] 탭을 클릭하고 명령 직접 입력
#  pip list
#  pymysql 목록 확인
#  없으면 설치
#  pip inpstall pymysql

# Step1. 관련 모듈 임포트
import pymysql

# Step2 - mysql의 계정의 특정 데이타베이스에 접속해서 연결 객체(conn) 생성
conn = pymysql.connect( host = 'localhost',
                        port=3306, # mysql 포트
                        user='root', # 접속 계정
                        password = '12345678', # 루트계정의 본인 비번
                        db = 'world',  # 접속하고자 하는 데이타베이스명
                        charset = 'utf8' )

print('conn => ', conn)
# <pymysql.connections.Connection object at 0x00000213E006A580>

# Step3 - 커서(cursor) 객체 생성
# 객체명 = 연결객체(conn).cursor()
cursor = conn.cursor()
print('cursor => ', cursor)


# Step4 - sql 명령을 실행
# 커서(cursor)객체.execute(sql명령문)
# 테이블 조회
cursor.execute('SELECT * FROM city LIMIT 10;')

# Step5 - sql 실행 결과 저장
# 변수명 = cursor.fetchall() / cursor.fetchone() / cursor.fetchmany(n)
result = cursor.fetchall()
print(type(result)) # 2차원 튜플
print(result)
for row in result[:5]:
    print(row)

# Step6 - 데이타베이스 종료
# conn.close()


# ===================
# fetch 관련 함수 테스트
# cursor.fetchone() => 튜플
# cursor.fetchall() => 2차원 튜플구조
# cursor.fetchmany(size) => 2차원 튜플구조

# country 테이블에서 레코드 저장
cursor.execute('''SELECT Code, Name, Continent, Population 
		                FROM country 
		                ORDER BY Population DESC LIMIT 20;
''')
# country_result = cursor.fetchall() #  2차원 튜플
country_result = cursor.fetchmany(5) #  2차원 튜플
# country_result = cursor.fetchone() # 튜플
print('-'*50)
print(len(country_result))
print(country_result)


# Step6 - 데이타베이스 종료
conn.close()