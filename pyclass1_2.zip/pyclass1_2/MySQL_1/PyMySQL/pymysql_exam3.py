# sampleDb 데이타베이스 생성
# sampleDb 데이타베이스 사용
# movieTbl 테이블 생성
# 레코드 삽입


# Step1. 관련 모듈 임포트
import pymysql

# Step2 - mysql의 계정의 특정 데이타베이스에 접속해서 연결 객체(conn) 생성
conn = pymysql.connect( host = 'localhost',
                        port=3306, # mysql 포트
                        user='root', # 접속 계정
                        password = '12345678', # 루트계정의 본인 비번
                        # db = 'sqldb',  # 접속하고자 하는 데이타베이스명
                        charset = 'utf8' )


# Step3 - 커서(cursor) 객체 생성
# 객체명 = 연결객체(conn).cursor()
cursor = conn.cursor()

# Step4 - sql 명령을 실행
# 커서(cursor)객체.execute(sql명령문)

# 데이타베이스 생성
sql = 'CREATE DATABASE IF NOT EXISTS sampleDb;'
cursor.execute(sql)

# 데이타베이스 사용
sql = 'USE sampleDb;'
cursor.execute(sql)

# 테이블 생성
sql = '''CREATE TABLE IF NOT EXISTS movieTbl
(
	movieNum int PRIMARY KEY NOT NULL AUTO_INCREMENT, 
    movieName varchar(30) NOT NULL,
	kind varchar(30) NULL,
    price int NOT NULL,
    period int NOT NULL
 );
'''
cursor.execute(sql)

# 레코드 삽입 1
# sql = '''INSERT INTO movieTbl VALUES
#             (NULL, '토이스토리', '애니메이션', 3000, 5)
# '''
# cursor.execute(sql)


# 레코드 삽입 2 : 필드명 지정 O
# sql변수 = '''  INSERT INTO 테이블명 (필드명1,...)
#                   VALUES (%s, .... ); '''
# cursor.execute(sql변수, (값1, ... ))

# sql = ''' INSERT INTO movieTbl (movieName, kind, price, period)
#             VALUES  (%s, %s, %s, %s)
#         '''
# cursor.execute(sql, ('원더우먼', '액션', 3000, 2))


# 레코드 삽입 3 : 필드명 지정 O, 다중 레코드 삽입 방식
# sql변수 = '''  INSERT INTO 테이블명 (필드명1,...)
#                   VALUES(%s, .... ); '''

# 레코드 데이타를 2차원 튜플로 저장
# data = ( (값1, 값2 ...), (값1, 값2 ...), (값1, 값2 ...), (값1, 값2 ...) ...)

# cursor.executemany( sql변수, data )

sql = ''' INSERT INTO movieTbl (movieName, kind, price, period)
            VALUES  (%s, %s, %s, %s);
        '''

data =  ( ('찰리 채플린', '코메디', 2000, 2),
          ('엔드게임', '액션', 1000, 1),
          ('슈퍼맨 리턴즈', '액션', 1500, 2))

cursor.executemany( sql, data )



# Step5 -  데이타베이스 반영(레코드 삽입, 삭제, 수정 후에는 적용과정 필요)
conn.commit()


# Step6 - 데이타베이스 종료
conn.close()
