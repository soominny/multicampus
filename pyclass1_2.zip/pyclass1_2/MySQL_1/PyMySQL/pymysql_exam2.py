# Step1. 관련 모듈 임포트
import pymysql

# Step2 - mysql의 계정의 특정 데이타베이스에 접속해서 연결 객체(conn) 생성
conn = pymysql.connect( host = 'localhost',
                        port=3306, # mysql 포트
                        user='root', # 접속 계정
                        password = '12345678', # 루트계정의 본인 비번
                        db = 'sqldb',  # 접속하고자 하는 데이타베이스명
                        charset = 'utf8' )


# Step3 - 커서(cursor) 객체 생성
# 객체명 = 연결객체(conn).cursor()
cursor = conn.cursor()

# Step4 - sql 명령을 실행
# 커서(cursor)객체.execute(sql명령문)
# 테이블 조회
# cursor.execute('SELECT * FROM userTbl;')

# sql 변수를 별도 지정 1
# sql = 'SELECT * FROM userTbl;'
# cursor.execute(sql)

# sql 변수를 별도 지정 2 - 다른 데이타베이스의 테이블 접근
# sql = 'SELECT * FROM userTbl;'
sql = 'SELECT * FROM world.city;'
cursor.execute(sql)


# Step5 - sql 실행 결과 저장
# 변수명 = cursor.fetchall() / cursor.fetchone() / cursor.fetchmany(n)
userTbl_data = cursor.fetchall()
for row in userTbl_data:
    print(row)

# Step6 - 데이타베이스 종료
conn.close()

# 마지막행만 출력
print('==> 마지막행만 출력')
print(userTbl_data[-1])

# 마지막행만 출력
print('==> 2행의 3~4 컬럼만 출력')
print(userTbl_data[1][2], userTbl_data[1][3] )