-- * 데이터베이스 종류
-- 		- 관계형 : MySQL, ORACLE, MSSQL, SQL-LITE …
--      - 비관계형 : 몽고DB…

-- * MySQL : 데이터베이스 조작언어. 관계형 데이터베이스에서 공통 사용

-- * 데이터베이스 구성요소 : 데이터베이스 > 테이블 > 행(레코드)과 열(필드,속성)

-- * SQL 언어 주석 
		-- 한줄 주석
		/*
		SQL 여러줄 주석입니다.
		단축키는 ctrl + / 
		*/		  

-- * SQL 문법 스타일 
-- 	: 명령어는 대소문자 구분 없음 
-- 	: 마지막에는 세미콜론(;)
-- 	: 명령어;

-- * SQL 명령 실행은 ? 블록을 지정하고 ctrl + enter 

-- * 데이터베이스 목록 확인 
show databases;


-- * 데이터베이스 접속하기 : USE 데이타베이스명;
USE employees;
USE world;

-- * 접속중인 데이터베이스의 테이블 목록 확인하기 : SHOW TABLES;
USE employees;
SHOW TABLES;

USE world;
SHOW TABLES;

-- * 접속중인 데이타베이스의 테이블 목록의 정보 확인하기 
SHOW TABLE STATUS;

-- * 특정 테이블의 정보 확인하기 
-- DESCRIBE 테이블명;
-- DESC 테이블명;
-- DESCRIBE(/DESC) 데이타베이스명.테이블명;
use employees;
show tables;
desc salaries;
desc employees;

-- * 다른 데이타베이스의 특정 테이블 정보 확인 
DESC world.city;

-- * 테이블의 레코드 출력하기
-- SELECT */필드명나열 FROW 테이블명;
-- SELECT */필드명나열 FROW 데이타베이스명.테이블명;
USE employees;
SHOW TABLES;

SELECT * FROM salaries;  -- 모든 레코드를 보여줌 
SELECT * FROM salaries LIMIT 5;   -- 5개의 레코드만 보여줌

-- ex) world 데이터베이스의 city 테이블 목록 확인 
SELECT * FROM world.city LIMIT 5;