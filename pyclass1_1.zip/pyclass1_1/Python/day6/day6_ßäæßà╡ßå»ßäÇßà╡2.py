# *** 파일 URL, encoding(cp949 또는 utf-8 둘중하나) 값을 매개변수로 전달받아서 파일내용을 반환 하는 함수 만들어보기
# 1) cp949 형
import os


def read_file(url, enc):
    f = open(url, 'r', encoding=enc)
    result = f.read()
    f.close()
    return f'url={url} \nencoding={enc} \n{result}'


print(os.getcwd())  # /Users/parksoomin/PycharmProjects/pyclass
print(read_file('data/national_anthem.txt', 'cp949'))  # data폴더에 있는 national_anthem.txt 읽어오기식

# 2) utf-8 형식
import os


def read_file(url, enc):
    f = open(url, 'r', encoding=enc)
    result = f.read()
    f.close()
    return f'url={url} \nencoding={enc} \n{result}'


print(os.getcwd())  # /Users/parksoomin/PycharmProjects/pyclass
print(read_file('data/coding.txt', 'utf-8'))  # data폴더에 있는 coding.txt 읽어오기

# -----<Quiz>-----
# 파일의 단어 전체갯수와 포함된 단어 중 5개만 표시되는 함수를 정의하여라 (중복은 제거하기)
'''
def printWord(fileURL, op):
    #명령어 기입               
'''
''' >> 함수호출
    printWord('data/Yesterday.txt')
    >> 결과값
    파일명 : data/Yesterday.txt
    단어 갯수 : 134
    5개 출력 : ['Yesterday', 'All', 'my' ...] '''


def printWord(url, enc):
    f = open(url, 'r', encoding=enc)
    result = f.read()
    f.close()
    result_list = list(set(result.split()))  # set은 split을 통해 슬라이싱이 안되니까 중보제거하기 위해 set으로 바꾼후 다시 리스트로 바꾸
    print(f'파일명:{url}')
    print(f'단어갯수: {len(result_list)}')
    print(f'5개 출력 : {result_list[:5]}')


printWord("data/coding.txt", "utf-8")
#-----------------



# -----<Quiz>-----
# data_eng.txt, data_kor.txt 파일안의 데이타의 합과 평균을 구하는 함수를 정의하고 아래와 같이 출력하여라
# 함수 정의 => 파일읽기 => 리스트화
# => 리스트의 값 더하기(숫자형데이터로 변환) : 합
# => 합 / 리스트갯수 : 평균

'''
 >> 함수 호출
sumAvr('data/data_eng.txt', 'cp949')
sumAvr('data/data_kor.txt', 'cp949')

 >> 결과
파일명 =  data/data_eng.txt
데이터 수 =  12
합 =  933
평균 = 77.75

----------
파일명 =  data/data_kor.txt
데이터 수 =  12
합 =  892
평균 = 74.33
'''


def sumAvr(url, enc):
    f = open(url, 'r', encoding=enc)
    # 리스트화하기 (문자열로 저장이 됨)
    score_list = f.readlines()
    f.close()
    # ★합계와 평균을 구하가 위해서는 문자열을 숫자로 바꿔야함 (형변환)
    # 총합 구하기
    tot = 0
    for item in score_list:
        tot += int(item)

    print(f'파일명 = {url}')
    print(f'데이터 수 = {len(score_list)}')
    print(f'합 = {tot}')
    print(f'평균 = {tot / len(score_list):.2f}')  # 소수점2번째까


sumAvr('data/data_eng.txt', 'cp949')
sumAvr('data/data_kor.txt', 'cp949')
#-----------------


# -------------------------------------------------
# << 파일쓰기 >>
# 새로운 파일이 생성되면서 내용이 추가된다.
# 기존에 파일이 있다면 덮어쓰기된다.
# 파일변수 = open( 생성파일경로, 'w', encoding='cp949/utf-8')
# 파일변수.write(문자열)
# 파일변수.close()

print(os.getcwd())

# *** 현재 위치에 빈 파일 생성하기 : os.listdi(경로) -> 경로에 있는 파일 목록
# +) 만약 특정위치에 파일 생성 : os.chdir(특정위치)
f = open('sample_0.txt', 'w')
f.close()
print(os.listdir(os.getcwd()))
if 'sample_0.txt' in os.listdir(os.getcwd()):
    print('파일생성 성공')

# *** 특정 파일에 내용 쓰기
# 기존 파일 목록이 있는 경우에는, 덮어쓰기가 적용됨. 만약 덮어쓰기가 아니라 내용을 추가하기 위해서는 'a'모드로 해야함.
f = open('sample_0.txt', 'w', encoding='utf-8')
f.write('사과\n')
f.write('원숭이\n')
f.write('=' * 50)  # 줄바꿈이 없이 한줄로 나오게됨.
f.close()

# *** 반복문을 이용해서 파일에 내용추가하기
f = open('sample_1.txt', 'w', encoding='utf-8')
myFoodList = ['라면', '김치전', '모밀', '초밥', '샐러드']
count = 1
for item in myFoodList:
    f.write(str(count) + '=>' + item + '\n')
    count += 1
f.close()

# ----- <Quiz> -----
# data/Yesterday.txt 파일에서 10줄만 data/result_Yesterday.txt 파일에 저장하기
# 작업 과정 : 파일 읽기 -> 리스트 구조로 저장 -> 슬라이싱 = 리스트변수[0:10] -> 파일 쓰기
# <내 답>
print(os.getcwd())
f = open('../data/Yesterday.txt', 'r')
result = f.readlines()
print(result)
f.close()
ff = open('../data/result_Yesterday.txt', 'w', encoding='utf-8')
for i in range(0, 10):
    ff.write(f'{result[i]}')
ff.close()

# <강사님 답>
# f1 = open('Yesterday.txt', 'r')
# f2 = open('result_Yesterday.txt', 'w', encoding='utf-8')
# resultList = f1.readlines() # 리스트에 저장
# print(f'resultList = {resultList}')
# 리스트에서 '\n' 삭제
# for i in range(resultList.count("\n")):
#    resultList.remove('\n')
# print(f'resultList = {resultList}')

# 파일 쓰기
# cnt = 1
# for row in resultList[0:10]:
#    dataLine = str(cnt) + '행 => ' + row
#    f2.write(dataLine)
#    cnt += 1
#    print('내용이 추가되었습니다.')

# f1.close()
# f2.close()
# ------------------


# *** 내용추가하기
# 기존 파일에 내용이 추가된다.
# 파일변수 = open( 생성파일경로, 'a', encoding='cp949/utf-8')
# 파일변수.write(문자열)
# 파일변수.close()

# 1) 내용추가하기
f = open('sample_0.txt', 'a')
f.write('\n======start2======')
f.close()

# 2) 데이터를 입력받아 파일에 추가하기
f = open('sample_0.txt', 'a')
while True:
    item = input('데이터 삽입 (q 는 프로그램종료) ====> ')
    if item == 'q':
        break
    else:
        f.write('\n')
        f.write(item)
print('테스트 종료')
f.close()

# *** 삭제하기
# (1) 파일의 내용을 삭제  : 'w'모드 이용해서 빈파일로 덮어쓰면 됨
f = open('sample_0.txt', 'w', encoding='utf-8')
f.close()

# (2) 파일 자체를 삭제 : os.remove(삭제파일경로)
# 삭제할 파일이 없는 경우, 에러가 난다.
f = open('sample_0.txt', 'w', encoding='utf-8')

answer = input("파일을 삭제하시겠습니까 ? ...")
if answer.upper() == 'Y':
    os.remove('sample_0.txt')

# --------------------------------------------------
# <<with 문과 파일 입출력>>
# 파일.close() 를 사용할 필요가 없다.
# with open(파일경로, 'a'/'w'/'r', encoding='uft-8/cp949') as 파일변수:
#   명령문
# ★ 들여쓰기 꼭 해야함

# ex) 특정파일에서 1행~3행 출력하기
with open('../data/national_anthem.txt', 'r', encoding='cp949') as f :
    data_list = f.readlines()
    for row in data_list[0:3] :
        print(row)
# ex) 10~1까지 특정파일에 쓰기
with open('../data/sample_100', 'w', encoding='utf-8') as f :
    for i in range(10,0,-1) :
        f.write(str(i) + "\n")

# ex) 특정파일에 구구단 쓰기
with open('../data/sample_100', 'w', encoding='utf-8') as f :
    for i in range(2,10) :
        f.write(f'** {i}단 \n')
        for j in range(1,10) :
            f.write(f'{i} X {j} = {i*j} \n')
        f.write("---------- \n")

