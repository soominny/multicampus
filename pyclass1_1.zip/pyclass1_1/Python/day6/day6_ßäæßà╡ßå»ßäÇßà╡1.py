# *** 자신의 현재 작업폴더 위치 알아보는 것 -> os패키지 불러와야함
import os
# *** 현재 폴더 위치(경로) : os.getcwd
print(os.getcwd())
# *** 경로로 지정된 폴더의 파일 목록 등이 리스트로 반환 : os.listdir(경로)
print(os.listdir(os.getcwd()))
# *** 폴더 위치 변경 (=폴더 탐색)
os.chdir('../data') #data폴더로 이동하라는 명령
# -> /Users/parksoomin/PycharmProjects/pyclass에서  /Users/parksoomin/PycharmProjects/pyclass/data여기로 이동함
os.chdir('../') #../라는 것은 한단계 위로 올라가라는 뜻


# 파일입출력 : open이라는 명령어 사용
# 파일접근모드 : r=읽기, w=쓰기, a=추가
# 파일변수  = open(파일경로, 'r'/'w'/'a',encoding='utf-8/cp949')
# 파일변수.파일입출력함수(옵션)

# -------------------------------------------------
# < 파일읽기 >
# *** 파일변수 생성
# 파일변수  = open(파일경로, 'r', encoding='utf-8/cp949')
''' 파일변수.read() : 파일전체 문자열 구조 =>  문자열로 반환됨 
    파일변수.readline() : 파일에서 첫줄만 읽기 => 문자열로 반환됨 
    파일변수.readlines() : 각행이 리스트 구조로 변경 => 리스트로 반환됨 '''

#현재위치확인
print(os.getcwd())
#data 폴더 안에 있는 Yesterday.txt파일 읽어서 파일변수 생성하기
f=open('../data/Yesterday.txt', 'r')
print(f,type(f))  #<_io.TextIOWrapper name='Yesterday.txt' mode='r' encoding='UTF-8'> <class '_io.TextIOWrapper'>

# 1) 파일전체 불러오기
result1 = f.read()
print(result1)
print(type(result1))  # <class 'str'>  :  data형이 문자열이라는 것
#파일변수는 휘발성이어서 한번밖이 못씀! 그래서 한번썼으면 꼭 닫기. 아니면 오류
f.close()

# ★ 다시 파일객체를 생성해야함 (휘발성이어서 위에서 닫아버렸으니까)환
# 2) 파일의 첫줄만 불러오기
f=open('../data/Yesterday.txt', 'r')
result2=f.readline()
print(result2)

# ★ 다시 파일객체를 생성해야함 (휘발성이어서 위에서 닫아버렸으니까)
# 3) 각 행을 리스트로 반환하기
f=open('../data/Yesterday.txt', 'r')
result3=f.readlines()
print(result3)   #빈행은 '\n'이렇게 반환됨

# +) 3줄만출력
for i in range(3) :
    print(f'{i+1} 행=> {result3[i]}')
# +) 2행~4행까지 출력
for i in range(1,4) :
    print(f'{i + 1} 행=> {result3[i]}')

# (슬라이싱이용하는방법으로)
count = 2
for row in range(1,4) :
    print(f'{count}  => {row}')
    count+=1

# *** 리스트에 있는 '\n' 요소 삭제하기
print(result3.count('\n'))  #5개가 있음을 확인했음
print('\\n의 갯수는?', result3.count('\n')) #5개가 있음을 확인했음
#result3.remove("\n")
#print('\\n의 갯수는?', result3.count('\n')) #4개
# result.remove()는 처음에 있는 한개 삭제됨 따라서5개 전부 다 삭제하기 위해서는 for문 이용
for i in range(5):
    result3.remove("\n")
print('\\n의 갯수는?', result3.count('\n')) #0

# *** 2) 리스트의 모든 문자열 안에 있는 "\n" 삭제하기
# 문자열변수.replace(old,new)
temp=[]
for row in result3:
    temp.append(row.replace('\n','')) #'\n'을 ''로 바꾸기
print(temp)


# -----<Quiz>-----
# "Yesterdat.txt"는 몇개의 어구로 이루어져있을까?
# -> 공백을 기준으로 단어별로 리스트 저장
f=open('../data/Yesterday.txt', 'r')
result_list = result1.split()
print(result_list)
print(f'단어갯수 = {len(result_list)}')  #134개

# *** 리스트에서 중복된 것 제거하기
# -> set으로 바꾸면 중복이 제거됨 그리고 나서 다시 리스트로 변환하면됨
result_list2 = list(set(result_list))
print(result_list2)
print(f'단어갯수 = {len(result_list2)}')   #65개

#-----------------