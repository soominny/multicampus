# 퀴즈 1:
# 아래와 같이 3줄로 글자를 출력하는 4가지 방법은?
'''
파이썬
파이썬
파이썬
'''

print('''파이썬
파이썬
파이썬''')

print("""파이썬
파이썬
파이썬""")

# 퀴즈 2
# 홍길동 씨의 과목별 점수는 다음과 같다.
# 홍길동 씨의 평균 점수를 소숫점 둘째자리까지 출력하여라
'''
국어 : 86
영어 : 77
수학 : 55
평균 : ?
'''
avg = (86+77+55)/3
print('%.2f'%avg)

# 퀴즈 3
# 변수 a,b를 입력문을 이용하여 데이터를 저장한다.
# == 을 이용하여 a,b 가 같은지 True, False 로
# 출력하여라
'''
a값 입력 => 10
b값 입력 => 10
True
'''
a=10
b=10
print(a==b)

# 퀴즈 4
# 2개의 숫자를 입력받아 다음과 같이 출력하여라
# % 포맷 이용

# '''
# 숫자1을 입력하세요... 12
# 숫자2를 입력하세요... 12.345
#
# 입력받은 숫자1은 12 입니다.
# 입력받은 숫자1은 8진수로 14 입니다.
# 입력받은 숫자1은 16진수로 c 입니다.
# 입력받은 숫자2는 12.3 입니다.
# '''
data1=int(input("숫자1을 입력하세요..."))
data2=float(input("숫자2를 입력하세요..."))

print("입력받은 숫자1은 %d입니다." %data1)
print("입력받은 숫자1은 8진수로 %o입니다." %data1)
print("입력받은 숫자1은 16진수로 %x입니다." %data1)
print("입력받은 숫자2은 %.1f입니다." %data2)

# 퀴즈 5
# 홍길동씨의 주민등록번호는 881120-1068234
# 연월일과 숫자 부분을 나누어서 출력하여라.
'''
연월일 : 881120
숫자 : 1068234
'''
yearmonthday = 881120
number=1068234

print("연월일 : %-10d 숫자: %-10d" % (yearmonthday,number))

# 퀴즈 6
# 2개의 변수를 정의하고 아래와 같이 출력한다.
# format 또는 % 또는 f'' 이용

'''
movie1 = '알라딘'
movie2 = '스파이더맨'

--------------
오늘의 영화 => 스파이더맨 , 알라딘

'''
movie1 = '알라딘'
movie2 = '스파이더맨'
print("오늘의 영화 => {} , {}".format(movie1,movie2))

# 퀴즈 7
# 다음과 같이 문자열 변수를 정의하고 결과값이 출력되도록 한다.
'''
Let thy speech be short, comprehending much in few words.

결과 >> 
첫번째 t의 위치 : ?
첫번째 m의 위치 : ?
s 의 갯수 : ?

= 이 모든 글자 사이에 연결되게 표시 : ?

모두 대문자로 표시 : ? 

'''

data= "Let thy speech be short, comprehending much in few words."
print(f"첫번째 t의 시작 위치 :  {data.find('t')}")
print(f"첫번째 m의 시작 위치 :{data.find('m')}")
print(f"s의 갯수 : {data.count('s')}")

print("=이 모든 글자 사이에 연결되게 표시 : ", data.strip().replace(' ','='))
print("모두 대문자로 표시 : ", data.upper())

# 퀴즈 8
# 아래와 같이 변수를 지정하고
# humidity = 82
# temperature = -1.8
# % 포맷, format(), f' 포맷 3가지 방식을 이용하여 다음과 같이 출력하여라

'''
오늘의 날씨 : 맑음, 습도 82%, 현재기온 -1.8
'''
humidity = 82
temperature = -1.8
print(f"오늘의 날씨 : 맑음, 습도 {humidity}%, 현재기온 {temperature}")
print("오늘의 날씨 : 맑음, 습도 {}%, 현재기온 {}".format(humidity,temperature))
print("오늘의 날씨 : 맑음, 습도 %d%%, 현재기온 %.1f" %(humidity,temperature))