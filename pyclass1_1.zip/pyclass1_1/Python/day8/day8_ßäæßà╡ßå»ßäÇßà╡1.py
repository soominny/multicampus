#day8_1 부분 지각으로 못들음 ..
#다음주 화요일이나 수요일 파이썬 과정 끝나서 시험있음

#기본자료형 < 집합자료형 < 함수 < 클래스 < 모듈(파일단위) < 패키지(폴더단위)
# << 패키지(Package) >>
# 도듈파일을 별도의 폴더에 저장하여 쓰는 기능
# 폴더는 패키지명으로 이용

# *** 파이참에서 패키지용도의 폴더만들기
# [project] 창에서 마우스 왼쪽 버트 - [New] - [Python Package]
# 패키지폴더가 생성되고 자동으로 __init__.py 파일 생성
# __init__.py : 패키지폴더임을 알려주는 파일

# ex) 별도패키지폴더명 - AAA , 패키지안에 모듈파일명 - AAA/a.py, 모듈파일안에 함수 정의 - testPrint 생성해보기
# *** 패키지안의 모듈안의 함수 호출
# 1. 방법 1
# import 패키지명.모듈명
# 패키지명.모듈명.함수(인자)
import AAA.a
AAA.a.testPrint()

# 2. 방법 2
# import 패키지명.모듈명 as 별칭
# 별칭.함수(인자)
import AAA.a as aa
aa.testPrint()

# 3. 방법 3
# from 패키지명.모듈명 import 함수
# 함수(인자)
from AAA.a import testPrint
testPrint()


# *** 패키지안의 패키지안의 모듈과 함수 테스트
# ex) 별도패키지폴더명 - AAA/BBB , 패키지안에 모듈파일명 - AAA/BBB/b.py, 모듈파일안에 함수 정의 - testPrint_B 생성하고 함수 불러오기
import AAA.BBB.b as bb
bb.testPrint_B()


# *** 다른 패키지의 모듈이나 그냥 모듈안의 클래스 호출하기
# 1. 그냥 모듈안의 클래스 호출하기
# ex) 같은 폴더안에 triangle.py 삼각형 클래스 정의하고 , triangle.py 호출해보기
import triangle
# 객체 생성 (모듈명.클래스명(인자))
t1 = triangle.Triangle('삼각형1',30,30)
t1.printInfo()
t1.printArea()

# 2. 다른 패키지의 모듈안의 클래스 호출하기
# ex) CCC 패키지폴더안의 모듈안의 클래스 정의하고, 테스트해보기
# CCC 패키지(폴더) / account 모듈(파일) / Account 클래스
import CCC.account
hong = CCC.account.Account('홍길동',3000)
hong.display_info()

# *** '*'명령으로 특정 패키지(폴더)안의 모든 모듈 불러오기
# 작업과정 : 패키지로 정의된 폴더안의 __init__.py 에서  __all__ = [모듈명1, 모듈명2...] 입력해야함 !

# from 패키지명 import *
# 함수 호출
# 모듈명.함수명 또는 모듈명.클래스명() 으로 호출가능

# ex) CCC 패키지 안의 account.py, triangle.py, helloworld.py 생성해서 * 이 명령어로 전부 호출하기
# 작업과정 : CCC패키지 안의 __init__.py 에다가 __all__ = ['account','triangle','helloworld'] 입력하기
from CCC import *
helloworld.hello_world()

t1 = triangle.Triangle('삼각형2',30,30)
t1.printInfo()
t1.printArea()

user1=account.Account('박수민',100000)
user1.display_info()
user1.deposit(100000)
user1.display_info()
user1.withdraw(1000)
user1.display_info()

#----------------------------------------------------------------------------
# << 오류 >> 교재 p222
# 파이썬은 인터프리터언어여서 오류가 발생하면 거기에서 딱 멈춤(그 이후부분은 실행 X)
# 만약 데이터를 불러올때, 중간에 이상한 데이터가 들어오면 오류발생하고 멈춤. 그 이후에 있는 유의미한 데이터들을 불러올 수 없음
# 따라서 오류가 발생하면 예외처리를 해줘야함

# *** 오류의 종류
# 1) NameError : 함수이름, 변수, 리스트이름 등이 잘못된 경우
# 2) IndexError : 튜플,리스트의 잘못된 인덱스 접근
# 3) ZeroDivisionError : 0으로 나눈 경우
# 4) FileNotFoundError : 잘못된 파일 경로
# 5) SyntaxError :문법적 오류   : SyntaxError는 예외처리 못해요 try: ~ Except 구문에서 제외
# 6) ValueError : 잘못된 값
# 7) TypeError : 잘못된 데이터

#1. NameError
''' print(a)        # > NameError: name 'a' is not defined '''

# 2. IndexError
# IndexError : list index out of range
# IndexError : tuple index out of range
''' 
myTuple = (1,)         # 1개짜리 튜플 생성 
print(myTuple[3])      # > IndexError: tuple index out of range
myList=[]              # 빈 리스트 생성 
print(myList[0])       # > IndexError : list index out of range 
'''

# 3. ZeroDivisionError
''' print(100/0)        # > ZeroDivisionError: division by zero '''

# 4. FileNotFoundError
'''
import os
os.remove('테스트.py')     # > FileNotFoundError: [Errno 2] No such file or directory: '테스트.py'
'''

# 5. SyntaxError
''' print('abcde)         # > SyntaxError: EOL while scanning string literal '''

# 6. ValueError
''' ans = int(input('숫자입력 => '))    # > ValueError: invalid literal for int() with base 10: 'ㄸ' '''

# 7. TypeError
myList = [100,56,77]
''' print(' '.join(myList))      # > TypeError: sequence item 0: expected str instance, int found '''


