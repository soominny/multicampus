#----------------------------------------------------------------------------
# << 예외처리 >>

# *** 예외처리 문법 1
# - 에러코드를 알고 있는 경우에 사용
# - e: 에러메시지
# try:
#    명령어
# except 에러코드 as e:
#    예외처리명령

# ex) 0으로 나눠서 발생하는 에러 : ZeroDivisionError
'''
n=int(input('숫자입력 => '))
try:
    print(100/n)
except ZeroDivisionError as e:
    print('에러메세지 = ',e,'0으로 나눌수 없어요.')
print('에러 테스트 종료')
'''

# ex) ValueError
'''
try :
    ans = int(input('숫자입력 => '))
except ValueError as e:
    print('에러메세지= ',e,'입력된 값이 숫자가 아닙니다.')
print('에러 테스트 종료')
'''

# *** 예외처리 문법 2
# 모든 예외는 예외 코드를 출력할 때는 Exception 키워드
# - 에러코드를 몰라도 된다. => Exception
# try :
#     명령어
# except Exception as e :
#       print(e)
'''
try:
    n=int(input('숫자 입력 => '))
    print(100/n)
except Exception as e:
    print('에러메세지 = ', e)
print('에러 테스트 종료')
'''

# *** 예외처리 문법 3
# try :
#     명령어
# except :
#     예외처리명령
'''
try:
    f = open('파일.txt','r',encoding='cp949')
    print(f.read())
except:
    print('파일이 없습니다.')
print('에러 테스트 종료')
'''

# *** 예외처리 문법 4
# try ... except ... else 명령
# try:
#     명령어
# except 에러코드 as e:  /except Exception as e : /except:   중 1개
#      에러발생 한 경우 명령어
# else:
#    에러가 발생하기 않은 경우 명령어
'''
try:
    f = open('파일.txt', 'r', encoding='cp949')  # > [Errno 2] No such file or directory: '파일.txt'  => 파일이 없습니다.
    f = open('data/Yesterday.txt', 'r', encoding='cp949')  # > Yesterday
except Exception as e:
    print(e, ' => 파일이 없습니다.')
else:
    print(f.readline())
'''

# *** 예외처리 문법 5
# try .. except .. else .. finally 명령
# try:
#     명령어
# except 에러코드 as e:  /except Exception as e : /except:   중 1개
#    에러발생 한 경우 명령어
# else:
#    에러가 발생하기 않은 경우 명령어
# finally :
#     에러가 발생하든 안하든 무건 실행되는 명령
'''
try:
    n=int(input('숫자 입력 => '))
    result = (100/n)
except Exception as e:
    print('에러메세지 = ', e)
else :
    print(result)
finally:
    print('에러 테스트 종료')
'''

# 예외처리 문법 6 : 오류회피
# 에러무시 : pass 키워드 사용
# try:
#     명령어
# except 에러코드:  /except Exception as e : /except:       중 1개
#      pass
# else:
#      ...
# finally:
#      ...
'''
myList = [1,2,3]
try:
    result=myList[100]
except:
    pass
else:
    print(result)
finally:
    print('에러 테스트 종료')
'''


# *** 여러개의 오류 처리하기
# - 먼저 발생한 오류 우선: 뒤에 오류는 실행되지 않음
# - 에러코드를 알고 있는 경우에 사용
# try:
#     명령실행 1
#     명령실행 2
#       ...
# except 발생오류1:
#     에러메세지 출력1
# except 발생오류2:
#     에러메세지 출력2
# finally:
#     테스트완료명령
'''
try:
    print(100/0)
    print(user1)
except NameError as e :
    print(f'NameError => {e}')
except ZeroDivisionError as e :
    print(f'ZeroDivisionError => {e}')
finally:
    print('테스트 종료')
'''


#----------------------------------------------------------------------------
# << 사용자 정의 에러 >>
# *** 에러만들기 1 : raise문 이용
# 일부러 에러 발생시키는 것
# if 조건식:
#    raise Exception(오류메세지)

# ex1) 입력값이 0이면 에러 발생시키기
'''
x = input('0이 아닌 문자를 입력하세요. => ')
if x == '0':
    raise Exception('입력 오류')            # > Exception: 입력 오류
else :
    print(f'x = {x}')
'''

# ex2) 입력값이 음수이면 에러 발생
'''
data = input('데이타 입력 => ')
if (data[0]=='-') and (data[1:].isdigit())  and (data != '-0'):
    raise Exception(f'{data} 는 음수')     # > Exception: -1 는 음수
elif data == '-0' :
    data = 0
else :
    print(f'data = {data}')
'''

# *** 사용자 정의 에러에 대해서도 예외처리하기
# try...except... + raise Exception
# ex1)
'''
try:
    x = input('0이 아닌 문자를 입력하세요. => ')
    if x == '0':
        raise Exception('입력 오류')       
except Exception as e:
    print(e)
else :
    print(f'x = {x}')
'''

# ex2)
'''
data = input('데이타 입력 => ')
try:
    if (data[0]=='-') and (data[1:].isdigit())  and (data != '-0'):
        raise Exception(f'{data} 는 음수')
    elif data == '-0' :
        data = 0
except Exception as e:
    print(e)
else :
    print(f'data = {data}')
'''


# *** 사용자 정의 에러도 에러코드 정의하기
# : Exception 내장 클래스를 상속받아서 에러코드 등록
# 에러코드 + 에러 메세지 등록

# 1단계 : 사용자 에러코드 등록 + 에러메세지 등록
# Exception 내장 클래스를 상속받아 임의의 에러명(에러코드)으로 클래스 생성
# class 에러명클래스(Exception):
#    def __str__(self):
#        return 에러메세지
# ex) 에러코드(MyError) 등록 + 에러메세지(MyError => 사용자정의 에러발생) 등록
class MyError(Exception):
    #에러 메세지 메서드
    def __str__(self):
        return 'MyError => 사용자정의 에러발생'

# 2단계 : 에러 발생시 에러코드 호출
# raise 에러코드클래스명()
# ex) 입력값이 0이면 오류 발생하도록 하기.
'''
x = input('0이 아닌 문자를 입력하세요 => ')
if x == '0' :
    raise MyError()                # > __main__.MyError
else :
    print(f'x = {x}')
'''

# try ... except 에러코드 as e 에 적용하기
'''
try:
    x = input('0이 아닌 문자를 입력하세요 => ')
    if x == '0':
        raise MyError()
except MyError as e:
    print(e)
else:
    print(f'x = {x}')
finally:
    print('테스트 종료')
'''

# ex) 닉네임 금칙어 에러 코드 만들기
# 닉네임 금칙어 : 바보, 멍청이, 똥

# 1단계 : 에러 코드 클래스 + 에러메세지  생성
'''
class NicknameError(Exception) :
    def __str__(self):
        return '닉네임 금칙어 에러 - 닉네임으로 사용할 수 없습니다.'
'''

# 금칙어가 들어가면 에러나는 함수 정의
'''
def check_nickname(nickname) :
    stop_nickname_list = ['바보','멍청이','똥']
    if nickname in stop_nickname_list :
        raise  NicknameError()
    else :
        return f'{nickname} 승인완료'
'''

# try ... except ..에 적용
'''
nickname = input('닉네임 입력 => ').strip()
try:
    print(check_nickname(nickname))
except NicknameError as e:
    print(e)
'''



#----------------------------------------------------------------------------
# 외부데이타 : txt , csv, tsv, dat, 엑셀 , openAPI(json, xml), 스크래핑(bs4, 셀레니움)
# << CSV >>
# Comma Seperate Value


# *** CSV 파일 읽기 1
# 파일변수 = open('csv 파일경로','r','encoiding='utf-8 / cp949')
# csv객체변수 = csv.reader(파일변수)
# ex)
import os, csv
# 데이터폴더로 이동
os.chdir('../')
print(os.getcwd())      # > /Users/parksoomin/PycharmProjects/pyclass/data

f = open('data/data.csv','r',encoding='utf-8')
csv_data = csv.reader(f)
print('csv_data = ',csv_data, type(csv_data))  # > csv_data =  <_csv.reader object at 0x7fd0ff45ae40> <class '_csv.reader'>

# for문 이용해서 list로 저장하기
data_list = []
for row in csv_data :
    data_list.append(row)
print(data_list)
print(f'data_list 의 전체 길이는? {len(data_list)}')
# 1행은 제목행 : Header
print(data_list[0])       # > ['class', 'name', 'kor', 'eng', 'mat', 'bio']
# 제목행을 제외하고 출력하기
for row in data_list[1:] :
    print(row)
# 인덱스 변수 이용해서 값으로 출력하기
for(cls, name, kor, eng, mat, bio) in data_list :
    print(cls,name, kor, eng, mat,bio)
f.close()


# *** CSV 파일 읽기 2
# with 문을 이용해서 csv 파일 읽어보기
# with open('csv파일경로', 'r', encoding='utf-8/cp949') as 파일변수:
#   csv객체변수 = csv.reader(파일변수)
# ex)
with open('data/population.csv', 'r', encoding='utf-8') as f:
    csv_data = csv.reader(f)
    pop_list = []
    for row in csv_data :
       pop_list.append(row)
print(f'행의 갯수는? {len(pop_list)}')      # > 행의 갯수는? 52
#header 빼고 1~10행만 출력하기
cnt = 1
for row in pop_list[1:11] :
    print(cnt,"행: ",row)
    cnt+=1
# 인덱스 변수 이용해서 값으로 출력하기
print('State','\t\t\t\t\t\t','Population')
for s,p in pop_list[1:11] :
    print(s,'\t\t\t\t\t\t',p)


# 데이터 가공 : ex)가장 인구가 많은 state 는? 이런건 다음시간에 !!