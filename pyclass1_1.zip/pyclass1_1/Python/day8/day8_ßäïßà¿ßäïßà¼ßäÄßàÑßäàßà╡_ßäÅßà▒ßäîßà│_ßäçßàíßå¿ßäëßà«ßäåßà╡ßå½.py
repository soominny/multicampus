# 퀴즈 1: FileNotFoundError
#  data/test.txt 가 없다면
#  에러메세지(e)와 함께 '파일이 없습니다.' 메세지 출력
#  있다면 파일의 내용을 출력한다.

# import os
#
# try :
#     os.remove('data/test.txt')
# except FileNotFoundError as e:
#     print('에러메세지= ',e,'파일이 없습니다. ')
# else:
#     print(f.read())
# print('에러 테스트 종료')


# 퀴즈 2: ValueError
# 2개의 숫자글자를 입력받아서 더한다.
# 입력된 글자가 숫자가 아니라면 에러 메세지 출력
# 입력된 글자가 숫자라면  더한후 출력한다.


# try:
#     a= input('숫자를 입력하세요 => ')
#     b= input('숫자를 입력하세요 => ')
#     if not (a.isdigit() and b.isdigit()):
#         raise Exception('입력 오류')
# except Exception as e:
#     print(e)
# else :
#     a = int(a)
#     b = int(b)
#     print(f'{a} + {b} = {a+b}')


# 퀴즈 3 : ValueError, ZeroDivisionError
# 2개의 데이타값을 입력받은 후 나누기 명령을 실행한다.
# 에러가 발생하면
#   에러 메세지 출력 : '데이타 오류 ...'
# 에러가 발생하지 않으면
#   결과 수행 : n1 / n2 = ?

# try:
#      a= int(input('숫자를 입력하세요 => '))
#      b= int(input('숫자를 입력하세요 => '))
# except ValueError as e :
#     print(f'ValueError => {e}')
# except ZeroDivisionError as e :
#     print(f'ZeroDivisionError => {e}')
# else :
#     print (f'{a} / {b} = {a/b}')



# 퀴즈 4
# data_eng.txt 파일을 파일 변수로 저장한다.
# data_eng.txt 파일이 없다면 (에러발생)
#   메세지 출력. => '파일없음'
# 파일이 있다면 (에러가발생하지 않는다면)
#   총합과 평균을 구하여 출력한다.



# try :
#     f = open('data/data_eng.txt', 'r')
# except:
#     print('파일없음')
# else :
#     list  = f.readlines()
#     tot = 0
#     for item in list:
#         tot += int(item)
#     print(f'총합  : {tot}')
#     print(f'평균  : {(tot / len(list)):.2f}')




# 퀴즈 5
# 함수의 매개변수값에 따라 다음과 같은 메세지를 출력한다.
# 0과 같거나 0보다 작다
# 0보다 크다
# 매개변수값이 숫자가 아닌경우에는 오류를 무시하도록
# try...except 문을 작성하여라

# try:
#     a = input("숫자 입력 => ")
#     if not a.isdigit() :
#         raise Exception('입력 오류')
# except :
#     pass
# else :
#     if int(a)<= 0 :
#         print('0과 같거나 0보다 작다')
#     else :
#         print('0보다 크다.')



# 퀴즈6
# 학생의 학년을 저장하는 변수 classYear값은
# 1학년, 2학년, 3학년, 4학년 이어야한다.
# 나머지 값은  raise Exception 을
# 이용하여 오류를 발생시켜라

# list = [1,2,3,4]
# classYear = input("몇 학년인가요 ? => ")
# if int(classYear[0]) not in list :
#     raise Exception('오류')
# else :
#     print(f'학년 :  {classYear}학년 ')




