# 퀴즈 ^^

# 퀴즈1 :
# data.csv 파일을 이용하여
# 4과목('kor', 'eng', 'mat', 'bio')의 총점과 전체 평균을 구하여라.
'''
 kor 총점 = ... ?
 eng 총점 = ... ?
 mat 총점 = ... ?
 bio 총점 = ... ?
4과목의 총점은 ... ?
전체 평균은 ... ?
'''

import csv,os
print(os.getcwd())
os.chdir('../')
print(os.getcwd())
with open('data/data.csv','r',encoding='utf-8') as f :
    csv_data = csv.reader(f)
    data_list = list(csv_data)
kor_data_list = []
eng_data_list = []
mat_data_list = []
bio_data_list = []
for c,v,k,e,m,b in data_list[1:] :
    kor_data_list.append(int(k))
    eng_data_list.append(int(e))
    mat_data_list.append(int(m))
    bio_data_list.append(int(b))
print(f'kor 총점 =  {sum(kor_data_list)}')
print(f'eng 총점 =  {sum(eng_data_list)}')
print(f'mat 총점 =  {sum(mat_data_list)}')
print(f'bio 총점 =  {sum(bio_data_list)}')
print(f'4과목의 총점 =  {sum(kor_data_list + eng_data_list +mat_data_list+ bio_data_list)}')
print(f'전체 평균은 ? {( (sum(kor_data_list)/len(kor_data_list)) + (sum(mat_data_list)/len(mat_data_list))+(sum(eng_data_list)/len(eng_data_list)) + (sum(bio_data_list)/len(bio_data_list)) ) / 4 :.2f}')



# 퀴즈2 :
# 미국 주별 인구수 population.csv 파일을 이용하여 리스트 구조로 변경하고
# 출력하여라
# 이때 인구와 관련된 데이타는 정수 리스트로 변환해야 한다.
'''
State Population
Alabama 4780131
Alaska 710249
Arizona 6392301
  ...
'''
with open('data/population.csv','r',encoding='utf-8') as f :
    csv_data = csv.reader(f)
    population_list = list(csv_data)

for (s,p) in population_list:
    p = p.replace(",","")
    print(s,p)


# 퀴즈3 :
# 퀴즈2의 리스트에서
# 가장 인구가 많은 주(State)와 가장 인구가 적은 주(state)는?
pop_data_list=[]
for (s,p) in population_list[1:]:
    p = p.replace(",","")
    pop_data_list.append(int(p))

for s,p in population_list[1:] :
    p = p.replace(",", "")
    if int(p) == max(pop_data_list) :
        print(f'가장 인구가 많은 주는? {s}')
    if int(p) == min(pop_data_list) :
        print(f'가장 인구가 적은 주는? {s}')


# 퀴즈5 :
# traffic_2017.csv 각 지역별 대중교통 파일을 이용하여
# 아래와 같은 딕셔너리 구조로 대중교통총사용자수를 출력하여라

'''
{'서울': 4423933, '부산': 952394, '대구': 547568, ... }

'''
#모르겠습니당...




# 퀴즈6 :
# 퀴즈 5번의 데이타 리스트에서 가장 낮은 대중교통 사용자수와 관련된 도시는?

#모르겠습니당...



# 퀴즈7 :
# 2018.csv 파일을 이용하여 다음을 구하여라.

# 1000명 이상인 회사에 들어간 취업자수가 가장 많은 도시는?
# 100인 미만의 회사에 들어간 취업자수가 가장 적은 도시는?
print(os.getcwd())
import pandas as pd
df = pd.read_csv('data/2018.csv', encoding='cp949')
print(type(df)) # <class 'pandas.core.frame.DataFrame'>
df.to_csv('output/2018_college1.csv', encoding='utf-8', index=False)

with open('output/2018_college1.csv', 'r', encoding='utf-8') as f:
  csv_data = csv.reader(f)
  data_list = []
  for row in csv_data :
      data_list.append(row)
  up_1000_list=[]
  down_100_list=[]
  for s, c, t, a1,a2, a3,a4,a5,a6 in data_list[1:]:
      a1=a1.replace(",","")
      a2=a2.replace(",", "")
      a3=a3.replace(",", "")
      a4=a4.replace(",", "")
      a5=a5.replace(",", "")
      a6=a6.replace(",", "")
      up_1000_list.append(int(a6))
      down_100_list.append(int(a1)+int(a2)+int(a3))

  for s, c, t, a1, a2, a3, a4, a5, a6 in data_list[1:]:
      a1 = a1.replace(",", "")
      a2 = a2.replace(",", "")
      a3 = a3.replace(",", "")
      a4 = a4.replace(",", "")
      a5 = a5.replace(",", "")
      a6 = a6.replace(",", "")
      if int(a6) == max(up_1000_list) :
          print(f'1000명 이상인 회사에 들어간 취업자수가 가장 많은 도시는?  {c}')
      if (int(a1)+int(a2)+int(a3)) == min(down_100_list):
          print(f'100인 미만의 회사에 들어간 취업자수가 가장 적은 도시는?   {c}')


# 퀴즈8 :
# 2018.csv 파일에서 '학제', '분석대상자수'  컬럼만 제외한 후
# output 폴더안에 2018_result.csv
# 파일로 저장하여라.

df = pd.read_csv('data/2018.csv', encoding='cp949')

df = df.drop(columns='학제')
df = df.drop(columns='분석대상자수')
df.to_csv('output/2018_result.csv', encoding='utf-8', index=False)



# 퀴즈9 :
# gapminder.tsv 파일을 이용하여 Asia 대륙의 데이타만 저장하여 별도 파일로 저장하여라.
# output 폴더안의 asia.tsv




# 퀴즈 10:
# gapminder.tsv 파일의 데이타를 이용하여 다음과 같이 출력하여라.
'''
 평균 수명이 가장 길었던 데이타 : ? 년도의 ? 
 평균 수명이 가장 짧았던 데이타 : ? 년도의 ?
'''




# 퀴즈 11:
# movies.dat 파일을 이용하여
# 1980년도 (1980~1989) 영화만
# movies_1980_1989.csv 파일로 저장하여라.

'''
MovieID,Title,Year,Genres
142,Shadows (Cienie),1988,Drama
541,Blade Runner,1982,Film-Noir|Sci-Fi
592,Batman,1989,Action|Adventure|Crime|Drama
 ... 
'''



# 퀴즈 12:
# movies.dat 파일을 이용하여
# Animation 장르의 데이타만 animation_movies.csv 파일로 저장하여라.
'''
MovieID,Title,Year,Genres
1,Toy Story,1995,Animation|Children's|Comedy
13,Balto,1995,Animation|Children's
48,Pocahontas,1995,Animation|Children's|Musical|Romance
...

'''

