# 특정 숫자에 대한 구구단 출력 함수 정의
def gugu() :
    n=int(input('숫자입력 => '))
    for i in range(1,10) :
        print(f'{n} * {i} = {n*i}')
