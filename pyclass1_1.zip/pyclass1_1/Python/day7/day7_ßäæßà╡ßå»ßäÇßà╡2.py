# << 클래스 변수 (=공용 변수) >>
# 클래스 정의시 지정된 공용 변수
# 생성자 함수 위에 정의하기 !
# 동일한 주소값을 가지고 있다.
# id(객체이름) : 주소 표시
# 인스턴스 생성후 접근
# - 인스턴스명.클래스변수명
# - 클래스명.클래스변수명

class Test :
    # 공용변수, 클래스변수
    msg = 'Test class입니다.'

    # 생성자 메서드
    def __init__(self,name):
        self.name = name

    # 일반 메서드
    def print_info(self):
        print('name => ',self.name)

# 객체 인스턴스화
test1 = Test('test1')
# 객체 속성 호출 - 인스턴스명.클래스변수명
print('test.msg?', test1.msg)
# 클래스 변수 호출 - 클래스명.클래스변수명
print('msg 속성은?', Test.msg)

#id(객체이름.속성) : 주소표시
print(id(test1.msg),id(Test.msg))    # > 140358273649840 140358273649840  : 두개의 주소는 같다

# ----------------------------------------------------------------------
# << 상속 (inheritance) >>
# 부모클래스의 속성이랑 메소드를 그대로 가진다.
# 장점: 코드의 재사용
# class 클래스이름(부모클래스1, 부모클래스2, ...)
# 부모클래스 = 조상클래스 = 슈퍼클래스
# 자식클래스 = 파생클래스 = 서브클래스

# ex) 부모클래스 => Country,  자식클래스 => Korea
# 부모클래스 정의
class Country :
    # 클래스 변수 정의
    name_title = '국가명'
    population_title = '인구'
    capital_title = '수도'

    # 일반 메서드 정의
    def show(self):
        print('국가 클래스의 메서드 show 입니다.')

# Country 클래스를 상속받는 자식 클래스 정의
class Korea(Country) :
    # 생성자 메서드 정의
    def __init__(self,name,capital, population):
        self.name = name
        self.capital = capital
        self.population = population

    # 속성 출력하는 일반 메서드 정의
    def show_info(self):
        print(self.name_title, self.name) #Korea 클래스에서 선언하지 않았지만, 부모한테서 상속받은 name_title 을 사용 가능
        print(self.capital_title, self.capital)# Korea 클래스에서 선언하지 않았지만, 부모한테서 상속받은 capital_title 을 사용 가능
        print(self.population_title, self.population) #Korea 클래스에서 선언하지 않았지만, 부모한테서 상속받은 population_title 을 사용 가능
        print()

# 인스턴스화
kor = Korea('한국','서울','5164만')
kor.show_info()
#부모 클래스에서 상속받은 메서드 호출
kor.show()

# *** 다중 클래스 상속
# 자식클래스 - 아파트, 차 , 오피스텔, 전동스쿠터, 로봇청소기, 김은주

# 부모클래스를 상속해서 자식 클래스 만들기
# class 자식클래스명(부모클래스명1, 부모클래스명2....):
#   명령문

# ex) 부모클래스1 Papa - 아파트, 차, 김철수
#     부모클래스2 Mama - 오피스텔, 전동스쿠터, 이영희
#     자식클래스 - 아파트, 차 , 오피스텔, 전동스쿠터, 로봇청소기, 김은주

# 부모 클래스 1
class Papa :
    family_name = '김'
    # 생성자 메서드 정의
    def __init__(self,name):
        self.name = name
    # 일반 메서드
    def asset_info1(self):
        print('아파트','차')
    def print_info(self):
        print(f'이름 => {self.family_name} {self.name}')

# 부모 클래스 2
class Mama :
    family_name = '이'
    # 생성자 메서드 정의
    def __init__(self,name):
        self.name = name
    # 일반 메서드
    def asset_info2(self):
        print('오피스텔','전동스쿠터')
    def print_info(self):
        print(f'이름 => {self.family_name} {self.name}')

# 자식 클래스 <= Papa, Mama 상속
class Child(Papa,Mama) :
    #생성자 메서드
    def __init__(self,name):
        self.name = name
    # 일반 메서드
    def asset_info3(self):
        print('로봇청소기')

    # def print_info(self):
    #     print(f'child 이름 => {self.family_name} {self.name}')

# 부모 클래스 인스턴스화
papa=Papa('철수')
papa.print_info()
papa.asset_info1()

mama=Mama('영희')
mama.print_info()
mama.asset_info2()

# 자식 클래스의 인스턴스화
child = Child('은주')
# 부모 클래스의 메서드 호출
child.asset_info1()   # > 아파트 차
child.asset_info2()    # > 오피스텔 전동스쿠터
child.print_info()     # > 이름 => 김은주
# 자식 클래스의 메서드 호출
child.asset_info3()

'''
# 부모 클래스 1
class Papa:
    # 클래스 변수
    family_name = '김'
    name = '철수'
    # 생성자 메서드
    # def __init__(self, name):
    #     self.name = name

    # 일반 메서드
    def asset_info1(self):
        print('아파트', '차')

    def print_info(self):
        print(f'Papa 이름 => {self.family_name} {self.name}')
        
# 부모 클래스 2
class Mama:
    # 클래스 변수
    family_name = '이'
    name = '영희'
    # # 생성자 메서드
    # def __init__(self, name):
    #     self.name = name

    # 일반 메서드
    def asset_info2(self):
        print('오피스텔', '전동스쿠터')


    def print_info(self):
        print(f'Mama 이름 => {self.family_name} {self.name}')
        
# 자식 클래스 <= Papa, Mama
# 우선순위 : 메서드 이름과 속성 이름이 같은 경우
# Child > Papa > Mama
class Child(Papa, Mama):
    def __init__(self, name):
        self.name = name

    def asset_info3(self):
        print('로봇 청소기')

    # 메서드 오버라이딩 :
    # 부모클래스에서 미리 정의된 메서드 이름과 동일한 메서드를 재정의하는 기능
    def print_info(self):
        print(f'child 이름 => {self.family_name} {self.name}')

# 부모 클래스 인스턴스화
print('='*50)
papa = Papa()
# papa.print_info()  # 이름 => 김 철수
papa.asset_info1() # 아파트 차

print('='*50)
mama = Mama()
# mama.print_info()  # 이름 => 이 영희
mama.asset_info2() # 오피스텔 전동스쿠터

print('='*50)
# 자식 클래스의 인스턴스화
child = Child('은주')
# 부모 클래스의 메서드 호출
child.asset_info1() # 아파트 차
child.asset_info2() # 오피스텔 전동스쿠터

# Papa 클래스의 print_info()
print('='*50 )
child.print_info() # child 이름 => 김 은주

# Child 클래스의 메서드 호출
child.asset_info3()

# 상속된 속성 확인
print('-'*50)
print('child.name => ', child.name)
# child.name =>  은주
print('family_name => ', child.family_name)
# family_name =>  김
'''

# 부모 클래스와 자식 클래스의 관계 확인
# issubclass(자식클래스,부모클래스)
# : 자식클래스와 부모 클래스와의 관계 표시 (True / False)
# 부모 클래스 정보 표시
# 클래스명.__bases__ => 튜플 형태
print(issubclass(Child,Papa))  # > True
print(issubclass(Child,Mama))  # > True
print(issubclass(Papa,Mama))   # > False
print(f'Child 클래스의 부모 클래스는? {Child.__bases__}')  # 튜플로 출력


#ex)
# 부모 클래스 : Tiger , Lion
# 자식 클래스 : Liger

class Tiger:
    kind = '호랑이'
    def jump(self):
        print('호랑이처럼 멀리 점프하기')
    def cry(self):
        print('호랑이 : 어흥 ~ ')

class Lion:
    kind = '사자'
    def bite(self):
        print('사자처럼 한입에 꿀꺽하기')
    def cry(self):
        print('사자 : 으르렁 ~ ')

# 자식 클래스
class Liger(Lion, Tiger):
    kind = '라이거'

    def play(self):
        print('라이거만의 사육사와 재미있게 놀기')

    # 메서드 오버라이딩(method overriding)
    def cry(self):
        print('라이거 : 어흥~ 으르렁~')

# 부모 클래스 인스턴스화
print('\n\n========tiger========')
tiger = Tiger()
print(tiger.kind, Tiger.kind)
tiger.cry()
tiger.jump()
'''
호랑이 호랑이
호랑이 : 어흥 ~ 
호랑이처럼 멀리 점프하기
'''
print('\n\n========lion========')
lion = Lion()
print(lion.kind, Lion.kind)
lion.bite()
lion.cry()
'''
사자 사자
사자처럼 한입에 꿀꺽하기
사자 : 으르렁 ~ 
'''

# *** 첫번째로 상속받은 부모클래스의 cry() 메서드를 사용하고 싶다면?
# super() 이용
def cry1(self):
    super().cry()


#----------------------------------------------------------------------------

# << 모듈(Module) >>
# *** 함수, 클래스의 집합 => 별도의 파일 (*.py)로 생성
# *** 모듈의 종류 (내부모듈 , 외부모듈, 사용자정의 모듈)
# 1) 내부모듈 : 파이썬에서 기본적으로 제공 (datetime, time, math, random)
# 2) 외부모듈 : 아나콘다를 이용해서 별도 설치 필요 ( pandas, numpy, mathplotlib, seaborn, flask ...)
# 3) 사용자정의 모듈 :  필요에 의해서 직접 모듈로 등록한 후 사용

# *** built_in 모듈의 호출방법
# 1. 모듈의 호출방법1
# import 모듈이름
# 모듈이름.함수(인자) / 모듈이름.속성
# ex) math 모듈안의 수학함수/속성 (sin(), cos(), tan(), pi....)
import math
print(math.pi)      # > 3.141592653589793
print(math.cos(1))  # > 0.5403023058681398

# 2. 모듈의 호출방법2
# import 모듈이름 as 별칭
# 호출된 모듈의 함수 호출방법2
# 별칭.함수(인자) / 별칭.속성
# ex) math 모듈안의 수학함수/속성 (sin(), cos(), tan(), pi....)
import math as m
print(m.pi)         # > 3.141592653589793
print(m.cos(1))     # > 0.5403023058681398

# 3. 모듈의 호출방법 3  : from사용, 모듈명 없이 함수만 바로 호출 가능
# from 모듈이름 import 모듈함수(인자) / 속성
# ex) math 모듈안의 수학함수/속성 (sin(), cos(), tan(), pi....)
from math import pi, cos
print(pi)       # > 3.141592653589793
print(cos(1))   # > 0.5403023058681398



# *** 사용자 정의 모듈
# ex) 같은 폴더 안에 있는 sample1.py 파일안에 함수 정의하고 , 현재 문서에서 sample1.py 함수의 호출해라.
# sample1.py 모듈을 import
import sample1
sample1.print_10()    # 1~10 출력하는 함수
print(sample1.print_sum100())    # 1~100 합 구하는 함수


# -----<Quiz>-----
# 구구단 모듈
# Step1. gugu.py로 입력한 숫자에 대한 구구단을 출력하는 모듈파일 생성
# Step2. import gugu로 모듈을 임포트 한 후 모듈이 실행되는지 확인

import gugu
gugu.gugu()

#-----------------


