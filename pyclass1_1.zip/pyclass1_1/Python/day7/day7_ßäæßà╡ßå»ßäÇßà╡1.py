# 교재 p183
# 파이썬 : 객체지향이니까 -> class 지원해줌
# class 를 설계도면 이라고 생각하고, class를 통해 객체를 생성
# class = 붕어빵 틀 ,  객체 = 붕어빵 틀로 인해 만들어진 실제의 붕어빵
# 기본자료형 (실수, 정수, 문자열, 논리형) < 집합형 < 함수 < 클래스(자료형+함수) < 모듈 < 패키
# 클래스명은 첫글자를 대문자로

# << 클래스 생성 >>
# *** 클래스 생성 문법
# class 클래스이름 :
#   명령문

# ex) 자동차 클래스 생성 , 버스 클래스 생성
class Car :
    pass

class Bus :
    pass

# -------------------------------------------------
# << 객체 인스턴스화 >>
# - 인스턴스변수 = 클래스이름()
# 인스턴스 명은 첫글자 소문자

# ex) 자동차,버스 생성 => 인스턴스
car1 = Car()
car2 = Car()
bus1 = Bus()

# *** 특정 클래스에 의해 생성된 객체인지 확인
# isinstance(인스턴스변수, 클래스이름)
print('bus1은 Bus 클래스에 의해서 생성된 객체인가?', isinstance(bus1,Bus))   # > True
print('bus1은 Bus 클래스에 의해서 생성된 객체인가?', isinstance(car1,Bus))   # > False


# -------------------------------------------------
# << 생성자 메서드 >>
# : 속성값을 정의하는 것
# 붕어빵이라는 객체에 대한 클래스 속성 => 재료, 칼로리, 크기, 생성날짜
# *** 생성자 메서드 문법
# class 클래스명:
# def __init__(self, 인자):
#     self.인자 = 인자값
#     self.인자 = (인자값1, 인자값2,...) # 튜플형태
# *** 실제 속성명 출력
# 인스턴스명.속성

# ex) 사각형에 대한 클래스 속성 => 가로, 세로, 만든사람(영희, 철수로 고정)
# 클래스 생성
class Square :
    # 생성자 메서드 정의
    def __init__(self,width,height):
        self.width = width
        self.height = height
        self.maker = ('영희', '철수')  #희 만든사람은 인자로 받지 않고, 영희 철수로 고정
# 객체 인스턴스화
s1 = Square(10,10)   #s1 = Square() 이렇게만 하면 Typeerror가 난다
s2 = Square(50,30)
# 인스턴스명.속성
print((f's1의 가로: {s1.width}, 세로: {s1.height}, 만든이: {s1.maker}'))
print((f's2의 가로: {s2.width}, 세로: {s2.height}, 만든이: {s2.maker}'))


# -------------------------------------------------
# << 클래스 메소드 >>
# : 동작/기능 을 나타냄
# *** 클래스 메소드 문법
# def 메소드이름(self,인자):
#   명령어
#   return 값
# *** 메소드 호출
# 인스턴스명.메소드이름(인자)

# ex) Bread 클래스 , 속성 => 빵종류, 가격, 칼로리, 재료, 브랜드 ,  메소드 => 정보출력, 주문한 빵에대한 가격 계산
class Bread :
    # 생성자 메서드 정의
    def __init__(self,kind,price,kcal,src):
        self.kind = kind
        self.price = price
        self.kcal = kcal
        self.src = src
        self.brand = '파리바게트'  #브랜드는 파리바게트로 고정!

    # 빵 속성 출력과 관련된 메서드 정의
    def print_info(self) :    #self를 쓰면 속성을 안 써도, 같은 클래스 내에서는 같은 속성이 적용
        print(f'종류 = {self.kind}')
        print(f'가격 = {self.price}')
        print(f'칼로리 = {self.kcal}')
        print(f'재료 = {self.src}')
        print(f'브랜드 = {self.brand}')

    # 주문한 빵에 대한 가격 계산 메서드 정의
    # 빵 갯수라는 새로운 매개변수가 필요 (count)
    def price_price(self, count):
        print(f'{self.kind} 을(를) {count} 개 주문하셨습니다.')   #self.count가 아닌 것 주의!
        print(f'주문 가격은? {self.price * count}원 ')

# Bread 인스턴스 생성
bread1 = Bread('팥빵', 3000, 350, ('밀가루','팥', '설탕'))
bread2 = Bread('마늘 바게트', 5500, 200, ('밀가루','마늘','버터'))

# 빵 종류만 출력 => 인스턴스명.속성
print(f'오늘의 빵 = {bread1.kind}, {bread2.kind}')

# 각 인스턴스의 해당되는 모든 속성 출력 => 인스턴스명.클래스메서드(인자)
bread1.print_info()
bread2.print_info()

# 주문 가격에 대한 메소드 호출
bread1.price_price(2)   # > 팥빵 을(를) 2 개 주문하셨습니다. 주문 가격은? 6000원
bread2.price_price(3)   # > 마늘 바게트 을(를) 3 개 주문하셨습니다. 주문 가격은? 16500원

# ex) Cat 클래스 , 속성 => 고양이 종류, 이름 , 나이, 성별  , 메소드 => 속성출력(print_info), 동작 : run, sleep(어디서), eat(무엇을)
class Cat :
    # 생성자 메서드 정의
    def __init__(self,kind,name,age,gender):
        self.animal_kind = '고양이'
        self.kind = kind
        self.name= name
        self.age = age
        self.gender = gender

    # 속성 출력과 관련된 메서드 정의
    def print_info(self):
        print(f' {self.animal_kind} 정보 출력 ')
        print(f' 종류 = {self.kind}')
        print(f' 이름 = {self.name}')
        print(f' 나이 = {self.age}')
        print(f' 성별 = {self.gender}')
        print()

    # 동작 메서드 정의
    def run(self):
        print(f'{self.animal_kind} {self.name}가 달린다.')
    def sleep(self,where):
        print(f'{self.animal_kind} {self.name}가 {where}에서 잔다.')
    def eat(self,food):
        print(f'{self.animal_kind} {self.name}가 {food}을(를) 먹는다.')

    # 정의메소드를 이용해서 새로운 메소드 정의
    def action_print(self):
        print(f'<{self.animal_kind} {self.name}의 아침 일상>')
        self.eat('물')
        self.eat('사료')
        self.run()
        self.eat('사료')
        self.sleep('쇼파')


#Cat 클래스의 인스턴스화
cat1 = Cat('코캣', '덩치', 1, '남')
cat1 = Cat('러시안블루', '나비', 5, '여')

# 메소드 호출
cat1.print_info()
cat1.run()
cat1.sleep('이불')
cat1.eat('참치')
cat1.action_print()


# -----<Quiz>-----
# 퀴즈1 - 삼각형 클래스를 다음과 같은 속성과 메서드로 정의하여라
# 속성(이름, 밑변, 높이, 도형의 종류)
# 메서드1 - 속성 출력
# 메서드2 - 삼각형의 넓이 출력
# 삼각형의 면적 구하는 공식 = (밑변의길이 * 높이)/2
class Triangle :
    def __init__(self, name, below, height):
        self.name = name
        self.below = below
        self.height = height
        self.type = '삼각형'

    def method1(self):
        print(f' {self.type} 정보 출력 ')
        print(f' 이름 = {self.name}')
        print(f' 밑변 = {self.below}')
        print(f' 높이 = {self.height}')
        print()

    def method2(self):
        print(f' {self.type}의 넓이 : {(self.below * self.height / 2)}')
# 퀴즈2 - 정의한 삼각형 클래스를 이용하여
# 인스턴스 객체를 생성하고 메서드를 호출하여라.
triangle1=Triangle('삼각형1',4,2)
triangle1.method1()
triangle1.method2()
#-----------------