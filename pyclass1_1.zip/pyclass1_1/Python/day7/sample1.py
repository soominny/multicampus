# 1~10 출력하는 함수 정의
def print_10() :
    for i in range(1,11) :
        print(i)


# 1~100 까지 합  구하는 함수 정의
def print_sum100() :
    result=0
    for i in range(1,101) :
        result+= i
    return(result)