# AAA 폴더안의 a.py
def testPrint():
    print('AAA 패키지 / a 모듈 / testPrint 함수')
