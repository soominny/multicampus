# AAA 폴더안의 BBB 폴더안의 b.py
def testPrint_B():
    print('AAA 패키지 / BBB 패키지 / b 모듈 / testPrint_B 함수')
