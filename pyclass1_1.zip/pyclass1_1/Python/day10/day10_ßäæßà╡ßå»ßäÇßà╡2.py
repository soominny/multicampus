from openpyxl import *
import os

# 워크북(엑셀파일) 객체 생성
# - 워크북객체 = Workbook()
wb = Workbook()

# 워크시트 생성
# - 워크시트객체 = 워크북객체.create_sheet(시트명)
ws = wb.create_sheet('생성시트')

# 워크시트객체 활성화
# - 워크시트객체 = 워크북객체.active
ws = wb.active

# 특정 셀안에 값 쓰기 1 (셀단위)
# - ws['필드명행인덱스'] = 값
ws['A1'] = 'Start1'
ws['B1'] = 'Start2'

# 특정 셀안에 값 쓰기 2 (셀단위)
# - 워크시트객체.cell(x,y,값)
ws.cell(2,1,'박수민')

# 특저 셀안에 값 쓰기 3 (행단위)
# - 워크시트객체.append(리스트/튜플)
ws.append([100,200,300])
ws.append([100,100])
# 엑셀파일에 쓰기
# - 워크북객체.save(액셀파일경로)
wb.save('output/tset1.xlsx')

# 액셀파일 닫기
# - 워크북객체.close()
wb.close()


#----------------------------------------------------------------------------
# *** 2차원 리스트를 엑셀파일로 저장하기
# 5행 10열
data_list = []
for i in range(1,6):
    temp =[]
    for j in range(1,11) :
        temp.append('python-'+str(i)+'-'+str(j))
    data_list.append(temp)
print(data_list)

wb = Workbook()
ws = wb.active
ws.append(['cell1','cell1','cell1','cell1','cell1'])
for row in data_list:
    ws.append(row)
wb.save('output/test2.xls')
wb.close()


#----------------------------------------------------------------------------
# << 데이터 수집 >>
# 교통안전정보관리시스템 https://tmacs.kotsa.or.kr/
# [교통사고 원인분석]-[교통사고 현황]-[지자체별 교통사고]

# ex) TrafficAccident2019.xlsx 파일을 이용헤서 교토사고 발생건수가 가장 높은 5대 시도의 데이터만 엑셀파일로 저장해라

# 워크북 객체 생성
wb = load_workbook('data/TrafficAccident2019.xlsx',data_only=True)
# 워크시트 객체 생성
ws = wb['2019']
print('\n'*5)
print(ws)        # > <Worksheet "2019">
# 제목 필드 리스트 생성
field_list = []
for row in ws['A2':'G2']:
    for cell in row:
        field_list.append(cell.value)
field_list[3] = '여객건'
field_list[4] = '화물건'

data_list = []
for row in ws.rows:
    temp=[]
    for cell in row:
        temp.append(cell.value)
    data_list.append(temp)
print(data_list)

# 필요한 데이터만 다시 재정의
print(data_list[3:-1])

# 판다스의 데이터프레임 모양으로 확인
import pandas as pd
df = pd.DataFrame(data_list,columns=field_list)
print(df)

# 교통사고 발생건수 기준으로 정렬
temp_list = []
for a, b, c, d, e, f, g in data_list:
    temp_list.append(b)
print ('Step1', temp_list)
#temp_list.sort()
#print ('Step2', temp_list)
# temp_list.reverse()
temp_list = temp_list[::-1]
print ('Step3', temp_list)

# 교통사고가 많은 데이터 5개만 저장하기
result_list=[]
for i in range(5):
    for a,b,c,d,e,f,g in data_list:
        if b == temp_list[i]:
            result_list.append([i+1,a,b])

print(result_list)
wb.close()

# 엑셀파일로 저장하기
wb = Workbook()
ws = wb.active
# 워크시트 이름 변경
ws.title = '교통사고 발생건수'
ws.append(['순위','시도','발생건수'])
for row in result_list:
    ws.append(row)
wb.save('output/traffic_accident5.xls')
wb.close()






#----------------------------------------------------------------------------
# << xml >>
# : extensible Markup Language
# 데이터 전송 목적, 다목적 마크업 언어
# open API에 많이 사용

# *** xml 문법
# open tag 와 close tag로 구성 = 요소(element)
# 1. <태그> ..... </태그>    :
# 2. <태그 />

# ex) 노트의 XML 구조
'''
<note>
  <to>Tove</to>
  <from>Jani</from>
  <heading>Reminder</heading>
  <body>Don't forget me this weekend!</body>
</note>
'''

# ex) person의 xml 구조  => name , id, age, address
'''
<person>
    <name>홍길동</name>
    <id>hong</id>
    <age>14</age>
    <address>서울</adress>
</person>
'''


# *** 트리구조
# 루트태그: 가장 바깥에 있는 태그   > 루트태그는 하나이다.
# 부모태그(parent), 자식태그(child)
# 속성(attribute)
# 1. <태그 속성=값> ...</태그>
# 2. <태그 속성= 값 /태그>

# *** xml.etree.ElementTree 모듈
# : xml 처리 모듈 - 파이썬의 내장모듈

# 관련 함수를 바로 사용할 수 있게 모듈 임포트
from xml.etree.ElementTree import *

# 외부 xml 파일 불러오기
'''
샘플 xml파일 생성하기
data/country_data.xml
소스는 아래 참조
https://docs.python.org/3/library/xml.etree.elementtree.html
'''

# xml객체 = parse(xmlURL)
tree = parse('data/country_data.xml')
print(tree,type(tree))

#루트찾기
# - 루트객체 = xml객체.getroot()
root=tree.getroot()
print(root)

# tag : 객체의 태그명 표시
# attrib : 객체의 태그 속성, 딕셔너리
print(root.tag)     # > 'data'
print(root.attrib)  # > {}

# root의 자식요소 찾기
for child in root:
    print(child.tag,child.attrib)

# root의 자식요소의 자식요소 찾기
for child in root:
    print('step1', child.tag, child.attrib)
    for child_sub in child:
        print('\tstep2', child_sub.tag, child_sub.attrib)
    print('='*50)


# *** 특정 태그의 정보 확인하기
# - 루트객체.iter(자식요소의 태그)
# ex) 모든 neighbor 태그의 속성 출력하기
for neighbor in root.iter('neighbor'):
    print(neighbor.attrib)
# ex) 모든 country 태그의 속성 출력하기
for country in root.iter('country'):
    print(country.attrib)

# text : <태그> </태그> 사이의 내용
# ex) country 태그의 하위 태그 정보
for country in root.findall('country'):     # iter 대신 findall 써도 됨
    print(country.find('rank').text)
    print(country.find('year').text)
    print(country.find('gdppc').text)


# find(태그명) : 첫번째 태그만 반환
# findall(태그명) : 모든 태그 반ㄴ환 => 집합형
print(root.find('country'))
print(root.find('country').text)
print(root.findall('country'))
# print(root.findall('country').text)  : 오류가난다

# ***.(도트)를 이용한 체이닝
# - root.find('태그명1').find('태그명2')

# ex) 첫번째 country 요소안의 rank에 삽입된 글자는?
print(root.find('country').find('rank').text)   # > 1

# ex) 두번째 country 요소안의 year 태그안에 글자 출력
print(root.findall('country')[1].find('year').text)   # > 2011

# *** 태그 안의 속성값 반환
# - get(속성명)
# ex) 모든 country 태그의 name 속성값만 출력하기
for country in root.findall('country'):
    print(country.get('name'),end=' ')      # > Liechtenstein Singapore Panama

# *** xml 데이터를 딕셔너리 리스트로 변환하고 csv파일로 저장하기
country_list = []
for country in root.findall('country') :
    temp = {}
    temp['rank'] = country.find('rank').text
    temp['year']=country.find('year').text
    temp['gdppc'] = country.find('gdppc').text
    country_list.append(temp)

import pandas as pd
import csv

# 방법1
# with open('output/country_result1.csv', 'w', encoding='utf-8', newline='') as f:
#     field_list = ['rank', 'year', 'gdppc']
#     csv_data = csv.DictWriter(f, fieldnames=field_list)
#     csv_data.writeheader()
#     csv_data.writerows(country_list)

# 방법2
df = pd.DataFrame(country_list,columns=['rank','year','gdppc'])
print(df)
df.to_csv('output/country_result2.csv' , index=False)


# -----<Quiz>-----
# 아래 주소를 이용하여 books.xml 파일을 생성한 후 bookstore.csv 파일로 저장하기
# xml -> 딕셔너리리스트 -> csv 저장
# https://www.w3schools.com/xml/books.xml
# author 태그의 텍스트가 여러개인 경우 첫번째만 저장
# title author year price
tree = parse('data/books.xml')
root=tree.getroot()

book_list=[]
for book in root.findall('book') :
    temp = {}
    temp['title'] = book.find('title').text
    temp['author']=book.find('author').text
    temp['year'] = book.find('year').text
    temp['price'] = book.find('price').text
    book_list.append(temp)

df = pd.DataFrame(book_list,columns=['title','author','year','price'])
print(df)
df.to_csv('output/bookstore.csv' , index=False)



# 여러개의 태그가 있는 경우 리스트화 한 후 텍스트로 변경하여  묶어서 저장하기
book_list=[]
for book in root.findall('book'):
    authors_list=[]
    for item in book.findall('author'):
        authors_list.append(item.text)
        temp['title'] = book.find('title').text
        temp['author'] ='/'.join(authors_list)
        temp['year'] = book.find('year').text
        temp['price'] = book.find('price').text
        book_list.append(temp)

df = pd.DataFrame(book_list,columns=['title','author','year','price'])
print(df)
df.to_csv('output/bookstore2.csv' , index=False)

#-----------------



#----------------------------------------------------------------------------
# << xml 구조의 문자열 변수 -> xml 객체 -> 딕셔너리 리스트 >>
# - xml객체 = fromstring(문자열변수)

# xml 구조의 문자열 변수 정의
str_xml = '''
<breakfast_menu>
<food>
    <name>Belgian Waffles</name>
    <price>$5.95</price>
    <description>
   Two of our famous Belgian Waffles with plenty of real maple syrup
   </description>
    <calories>650</calories>
</food>
<food>
    <name>Strawberry Belgian Waffles</name>
    <price>$7.95</price>
    <description>
    Light Belgian waffles covered with strawberries and whipped cream
    </description>
    <calories>900</calories>
</food>
<food>
    <name>Berry-Berry Belgian Waffles</name>
    <price>$8.95</price>
    <description>
    Belgian waffles covered with assorted fresh berries and whipped cream
    </description>
    <calories>900</calories>
</food>
</breakfast_menu> '''
print(type(str_xml))       # > <class 'str'>

# 문자열 -> xml 객체화
# - xml객체 = fromstring(str_xml)
root = fromstring(str_xml)
print(type(tree))       # > <class 'xml.etree.ElementTree.Element'>

food_list = []
for food in root.findall('food'):
    temp = {}
    temp['name'] = food.find('name')
    temp['price'] = food.find('price')
    temp['description'] = food.find('description')
    temp['calories'] = food.find('calories')
    food_list.append(temp)
print(food_list)

df = pd.DataFrame(food_list, columns=['name', 'price', 'description', 'calories'])
print(df)
df.to_csv('output/breakfast_menu.csv', index=False)

# root 객체 =>  xml 파일로 저장하기
# ElementTree(root).write(xml경로, encoding='cp949/utf-8')
print(root)
print(root.tag)
ElementTree(root).write('output/breakfast_menu.xml', encoding='utf-8')