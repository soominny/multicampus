# << 엑셀 파일 다루기 >>
# 관련 모듈 : openpyxl
# https://openpyxl.readthedocs.io/en/stable/
# 터미널 모드에서  명령 확인
# pip list
# openpyxl 목록 확인
# 없으면 설치
# pip install openpyxl
# 파이참 프로그램에서는 [File]-[Settings]

# *** 엑셀 구성요소
# 워크북(workbook=엑셀파일) > 워크시트(worksheet) > 셀(Cell)

# *** 모듈 임포트
# - import openpyxl
# 모듈명 없이 바로 함수 호출
# - from openpyxl import *
from openpyxl import *
import os

# *** 엑셀파일(xlsx, xls) 불러오기
# 액셀 워크북객체 생성
# - 워크북객체변수 = load_workbook(url, data_only=True)
wb = load_workbook('data/sample.xlsx',data_only=True)
print(wb)
# 워크시트 객체 생성
# - 워크시트객체변수 = 워크북객체[워크시트명]
ws = wb['영업사원매출']
print(ws)
# 워크시트안의 셀 주소 접근
# - 워크시트객체변수['컬럼명행번호'].value
# 또는 워크시트객체변수.cell(x,y).value     : x,y는 행과 열의 익덱싱 (1부터 시작)
print(ws['A1'].value)        # > Sap Co.
print(ws.cell(1,1).value)    # > Sap Co.

# *** for문을 이용해서 특정 셀 안의 내용을 출력
# ex) 1행만 출력하기
for row in ws['A1':'G1']:
    for cell in row:
        print(cell.value,end=' ')     # > Sap Co. 대리점 영업사원 전월 금월 TEAM 총 판매수량
# ws.rows : 모든행
# ws.columns : 모든 열
# ex) 모든 행  출력
print('-'*50)
for row in ws.rows:
    print(row)   # 값이 아니고 셀이 튜플형태로 나옴

# ex) 모든 행의 셀 값을 출력  ( 행 단위로 )
print('-'*50)
for row in ws.rows :
    for cell in row :
        print(cell.value, end=' ')
    print()

# ex) 모든 열 출력
print('-'*50)
for column in ws.columns:
    print(column)   # 값이 아니고 셀이 튜플형태로 나옴

# ex) 모든 컬럼의 셀 값을 출력  ( 컬럼 단위로 )
print('-'*50)
for column in ws.columns :
    for cell in column :
        print(cell.value, end=' ')
    print()


# *** 모든 셀 안의 값을 2차원 리스트로 저장 (행단위로)
all_values=[]
for row in ws.rows:
    temp=[]
    for cell in row:
        temp.append(cell.value)
    all_values.append(temp)
print(all_values)

print(all_values[0])   # 헤더
print(('-')*30)
for a, b, c, d, e, f, g in all_values[1:] :
    print(a,b,c,d,e,f,g)

# ex ) 금월 매출액의 최댓값과 매출액이 가장 높은 영업사원 구하기
# 금월 매출액의 최댓값 구하기
result_list = []
for a, b, c, d, e, f, g in all_values[1:] :
    result_list.append(e)
print('금월 매출액의 최댓값 = ', max(result_list))

for a, b, c, d, e, f, g in all_values[1:] :
    if e == max(result_list) :
        print(f'금월 매출액이 가장 높은 영업사원 ... ? {b},{f}팀의 {c}사원')

# ex) 금월 영업 실적이 전월보다 떨어진 영업사원의 목록은 ?
# 금월 영업실적 - 전월 영업실적 < 0
for a,b,c,d,e,f,g in all_values[1:]:
    if e-d < 0:
        print(b,c,e-d)

# -----<Quiz>-----
# 경기도 지역의 영업 사원 목록 데이터만 csv 파일로 저장하기
# output/sample_result.csv

import csv
g_list = []
for a, b, c, d, e, f, g in all_values[1:]:
    if '경기' in b:
        g_list.append([a, b, c, d, e, f, g])

print(g_list)

# 데이터 프레임 생성
# - 데이터 프레임 변수 = pd.DataFrame(2차원데이터/딕셔너리리스트 , columns=필드리스트)
import pandas as pd
df = pd.DataFrame(g_list[1:],columns=g_list[0])
print(df)

# 데이터프레인 -> csv 쓰기
# - 데이터프레임변수.to_csv('csvURL',encoding='utf-8,cp949',index=False)
# index = False : 인덱스 컬럼 저장 여부
df.to_csv('output/sample_result.csv',encoding='utf-8',index=False)

#-----------------

# 워크북 객체 닫기
wb.close()

