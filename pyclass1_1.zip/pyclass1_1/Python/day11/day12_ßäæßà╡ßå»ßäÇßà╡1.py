# << 정규표현식 (Regular Expression) >>
# 유효성 검사 : 문자열에서 특정 조건(패턴)에 맞는 문자열 찾기
# ex) 회원가입시 주민등록번호 형식이 맞는가 ?
# ?????? - ???????
# ex) 핸드폰 번호 형식이 맞는가?
# 01(0|1|7|9)-????-????
# ex) 회원가입 시 비밀번호 설정 형식이 맞는가?
# 자릿수, 특수문자 + 숫자 + 영문대문자 + 영문 소문자

# *** 파이썬에서 정규표현식 모듈 : re (내장모듈)
import re

# re 객체의 속성과 메소드 확인
print(dir(re))
for i in dir(re):
    print(i)

# *** 정규표현식 패턴1 - 대문자, 소문자, 숫자, 한글
# [문자클래스스타일]  => 한글씩
# [문자클래스스타일]+ => 단어단위
# [a-z] : 영어소문자
# [A-Z] : 영어대문자
# [0-9] : 숫자
# [가-흫] / [가-힣]: 한글

# *** 정규표현식 패턴2 - 대문자, 소문자, 숫자 : \지원문자
# [\d] : 10진수, [0-9]와같음
# [\D]: 10진수외 [^0-9]
# [\s] :공백문자, [ \t\n\r\f\v]
# [\S]: 공백 문자 외, [ \t\n\r\f\v]
# [\w] : 영문자숫자 , [a-zA-Z0-9]
# [\W]: 영문자숫자외 , [^a-zA-Z0-9]

#-----------------------------

# *** 정규표현식 적용방식 1
# - 패턴식변수 = re.compile(패턴식)
# - 패턴식변수.정규표현식메소드(문자열)
txt = 'JAVA 도레미 파솔라 시도 !<$@ Python mysql 12 3'
# 날글자 단위 패턴
pattern1 = re.compile('[A-Z]')
pattern2 = re.compile('[a-zA-Z]')
pattern3 = re.compile('[가-힣]')
pattern4 = re.compile('[0-9]')

# 단어 단위 패턴
pattern5 = re.compile('[A-Z]+')
pattern6 = re.compile('[a-zA-Z]+')
pattern7 = re.compile('[가-힣]+')
pattern8 = re.compile('[0-9]+')


# 패턴식에 맞는 문자열을 리스트로 반환
# - 패턴식변수.findall(문자열)

print(pattern1.findall(txt))
print(pattern2.findall(txt))
print(pattern3.findall(txt))
print(pattern4.findall(txt))
print(pattern5.findall(txt))
print(pattern6.findall(txt))
print(pattern7.findall(txt))
print(pattern8.findall(txt))


pattern_a = re.compile('[\w]+')
pattern_b = re.compile('[\D]+')
pattern_c = re.compile('[\s]')
print(txt)
print(pattern_a.findall(txt))
print(pattern_b.findall(txt))
print(pattern_c.findall(txt))



# *** 정규표현식 적용방식 2
# 문자열변수 = 문자열값
# re.정규표현식메소드(패턴식, 문자열변수)
# re.match(패턴식, 문자열변수) => 문자열
# re.search(패턴식, 문자열변수) => 문자열
# re.findall(패턴식, 문자열변수) => 리스트
# re.finditer(패턴식, 문자열변수) => 반복가능객체
