# 5문제 정도만 코딩하신후 보내주시면 됩니다.
import os
from urllib.request import urlopen
import json
import pandas as pd
os.chdir('../')

# # 퀴즈1 : 웹상의 json 파일을 파이썬의 딕셔너리 리스트로 생성하고 총 몇개인지 출력하여라.
# # url - http://jsonplaceholder.typicode.com/photos

url ='http://jsonplaceholder.typicode.com/photos'
request = urlopen(url)
json_str = request.read()
from bs4 import BeautifulSoup

todos = json.loads(json_str)
count = 0
for item in todos:
    for key in item:
        print(key,'=>', item[key], end=' / ')
        count +=1
    print()
print('딕셔너리 리스트의 총 갯수는 ? ', count,'개')

print('='*60)


# # 퀴즈2 : 퀴즈 1의 딕셔너리 리스트에서 마지막 딕셔너리 리스트를 아래와 같은 형식으로
# # 출력하여라

'''
albumId => 100
id => 5000
title => error quasi sunt cupiditate voluptate ea odit beatae
url => https://via.placeholder.com/600/6dd9cb
thumbnailUrl => https://via.placeholder.com/150/6dd9cb
'''
item=todos[-1]
for key in item:
    print(key,'=>', item[key], )

print('='*60)


# # 퀴즈3 : 퀴즈 1의 딕셔너리 리스트에서 albumId 가 22인 딕셔너리 리스트에서
# # title 과 url 값만 모두 출력하여라

for i in range(len(todos)):
    if todos[i]['albumId'] == 22 :
        print('title : ',todos[i]['title'])
        print('url : ',todos[i]['url'])
        print('-'*30)


# # 퀴즈4 : 퀴즈 1의 딕셔너리 리스트에서 10개만 json 파일로 저장하여라.

data = todos[0:10]
with open('output/result11.json', 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent='\t')


# # 퀴즈5 : 퀴즈4에서 생성된 json 파일을 이용하여 딕셔너리 리스트를 생성하고
# # 출력하여라.

'''
key = albumId, value = 1
key = id, value = 1
key = title, value = accusamus beatae ad facilis cum similique qui sunt
key = url, value = https://via.placeholder.com/600/92c952
key = thumbnailUrl, value = https://via.placeholder.com/150/92c952

...
'''

with open('output/result11.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

for i in range(len(data)):
    dict = data[i]
    for j in range(5) :
        print (f'key = {list(dict)[j]} , value = {list(dict.values())[j]}')
        print('-'*10)




# 퀴즈 6 : 아래 주소를 참조하여 기상청 육상 중기예보 RSS 데이타에서
# 부산 지역과 관련된 데이타만 출력하여라.
# https://www.weather.go.kr/weather/forecast/mid-term-rss3.jsp?stnId=108


# 퀴즈 7 : 아래 주소를 참조하여 기상청 육상 장기예보 1개월 전망 데이타에서
# '강원도 영서'와 '강원서 영동' 지역과 관련된 데이타만 csv 파일로 저장하여라.
# https://www.kma.go.kr/repositary/xml/fct/mon/img/fct_mon1rss_108_20210107.xml


# 퀴즈 8 : 아래 주소를 참조하여 구글 뉴스의 RSS 에서 item태그와 관련된 데이타만  저장하여라.
# 구글 뉴스 RSS : https://news.google.com/rss?hl=ko&gl=KR&ceid=KR:ko



# 퀴즈 9 : 퀴즈 6의 부산지역 데이타를 json 구조로 변경하고 json 파일로 저장하여라.

