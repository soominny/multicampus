import random

class Account:
    # 클래스 변수
    account_count = 0

    # 생성자 메서드
    def __init__(self, name, balance):
        self.name = name
        self.balance = balance
        self.bank = "SC은행"
        self.account_number = str(random.randint(100,999)) + '-' \
                              + str(random.randint(10,99)) + '-' \
                              + str(random.randint(100000,999999))
        # 계좌 생성시 누적 카운트
        # 클래스.클래스변수 로 접근 가능
        Account.account_count += 1

    # 생성된 인스턴스를 출력하는 메서드
    def get_account_num(self):
        print(f'총 계좌수 : {Account.account_count}')

    # self 값이 없는 메서드 => 클래스 메서드
    # 클래스명.메서드() 접근 가능
    def get_account_num2():
        print(f'총 계좌수 : {Account.account_count}')

    # 입금 메서드
    # 입금 금액은 1보다 커야한다.
    # 입금 금액은 잔액(balance)에 누적된다.
    def deposit(self, amount):
            if amount >= 1:
                self.balance += amount
            else:
                print('입금 오류')

    # 출금 메서드
    # 잔액에서 출금만큼 금액은 인출되어야 한다.
    # 출금 금액은 잔액보다 작아야한다.
    def withdraw(self, amount):
            if self.balance > amount:
                self.balance -= amount
            else:
                print('출금 오류')

    # 계좌 정보 출력 메서드
    def display_info(self):
        print("은행이름 : ", self.bank)
        print("예금주 : ", self.name)
        print("계좌번호 : ", self.account_number)
        print("잔고 : ", self.balance)

# hong = Account('홍길동', 800)
# hong.display_info()