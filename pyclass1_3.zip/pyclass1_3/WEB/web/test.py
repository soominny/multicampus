# 화면 확대 축소 => [Ctrl] + [-]
# 주석 단축키는? => [Ctrl] + [/]
print('Hellow world')