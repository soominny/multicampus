print('Hello world')
print('Yes')