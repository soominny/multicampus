import urllib.request
import datetime
import time
import json
from config import *
def get_request_url(url, enc='utf-8'):        
    req = urllib.request.Request(url)
    try :
        response = urllib.request.urlopen(req)
        if response.getcode() == 200:
            try:
                rcv = response.read()
                ret = rcv.decode(enc)
            except UnicodeDecodeError:
                ret = rcv.decode(enc,'replace')
            return ret
    except Exception as e:
        print(e) 
        print("[%s] Error for URL: %s" % (datetime.datetime.now(), url))
        return None

def getItemTradeList(searchBgnDe,searchEndDe,searchItemCd):
    endPoint = 'http://openapi.customs.go.kr/openapi/service/newTradestatistics/getitemtradeList'
    parameter = '?_type=json&serviceKey='+ service_key
    parameter += '&searchBgnDe='+ searchBgnDe
    parameter += '&searchEndDe='+ searchEndDe
    parameter += '&searchItemCd='+searchItemCd
    url = endPoint + parameter
    #print(url)
    retData = get_request_url(url)
    if retData == None: return None 
    else : return json.loads(retData)

searchBgnDe ='201701'
searchEndDe ='201802'
searchItemCd='9701101000'
jsonData = getItemTradeList(searchBgnDe,searchEndDe,searchItemCd)
print(jsonData)
result=[]
statKor=''
if jsonData['response']['header']['resultMsg']=='NORMAL SERVICE.':
    for item in jsonData['response']['body']['items']['item']:      
        if item['hsCode'] == '-':
            break 
        else :
            balPayments = item['balPayments']
            expDlr = item['expDlr']
            expWgt = item['expWgt']
            hsCode = item['hsCode']
            impDlr = item['impDlr']
            impWgt = item['impWgt']
            statKor = item['statKor']
            year = str(item['year']).replace('.','')
            print(year, balPayments)
            result.append([year]+[statKor]+[hsCode]+[balPayments]+[expDlr]+[expWgt]+[impDlr]+[impWgt])

print(result)

import pandas as pd 

itemlist_table = pd.DataFrame(result, columns=('year','statKor','hsCode','balPayments','expDlr','expWgt','impDlr','impWgt'))
itemlist_table.to_csv('%s_%s품명별실적(%s)'%(searchBgnDe,searchEndDe,statKor)+'.csv',index=False)