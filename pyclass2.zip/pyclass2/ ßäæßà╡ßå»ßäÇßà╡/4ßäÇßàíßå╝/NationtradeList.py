import urllib.request
import datetime
import time
import json
from config import *
def get_request_url(url, enc='utf-8'):        
    req = urllib.request.Request(url)
    try :
        response = urllib.request.urlopen(req)
        if response.getcode() == 200:
            try:
                rcv = response.read()
                ret = rcv.decode(enc)
            except UnicodeDecodeError:
                ret = rcv.decode(enc,'replace')
            return ret
    except Exception as e:
        print(e) 
        print("[%s] Error for URL: %s" % (datetime.datetime.now(), url))
        return None


def getNationtradeList(searchBgnDe, searchEndDe,searchStatCd, numOfRows,pageNo ):

    endpoint ='http://openapi.customs.go.kr/openapi/service/newTradestatistics/getnationtradeList'
    #searchBgnDe=201601&searchEndDe=201601&pageNo=1&numOfRows=10&serviceKey'
    parameters = '?_type=json&serviceKey='+ serviceKey
    parameters += '&searchBgnDe=' + searchBgnDe
    parameters += '&searchEndDe='+ searchEndDe
    parameters += '&searchStatCd='+ searchStatCd
    parameters += '&numOfRows=' + numOfRows
    parameters += '&pageNo=' + pageNo
    url = endpoint + parameters
    print(url)
    retData = get_request_url(url)
    if retData == None : 
        return None
    else:
        return json.loads(retData) 
    
    
result = []
searchBgnDe ='200101'    
searchEndDe = '200112'
searchStatCd = 'US'
numOfRows='100'
pageNo='1'
jsonData = getNationtradeList(searchBgnDe, searchEndDe,searchStatCd, numOfRows,pageNo)
#print(json.dumps(jsonData, indent=4, sort_keys=True, ensure_ascii=False)) 
print(jsonData)
if(jsonData['response']['header']['resultMsg'] == 'NORMAL SERVICE.'):
    totalCount= jsonData['response']['body']['totalCount']
    print(totalCount)
    for i in range(int(totalCount)):            
        staCD = jsonData['response']['body']['items']['item'][i]['statCd']
        krName = jsonData['response']['body']['items']['item'][i]['statCdCntnKor1']
        #krName = krName.replace(' ','')
        expDlr = jsonData['response']['body']['items']['item'][i]['expDlr']
        impDlr = jsonData['response']['body']['items']['item'][i]['impDlr']
        balPayments = jsonData['response']['body']['items']['item'][i]['balPayments']
        expCnt = jsonData['response']['body']['items']['item'][i]['expCnt']
        impCnt = jsonData['response']['body']['items']['item'][i]['impCnt']
        yyyymm = str(jsonData['response']['body']['items']['item'][i]['year'])
        yyyymm = yyyymm.replace('.','')
        print("%s_%s : %s" %(krName,yyyymm,  balPayments))
        result.append([yyyymm]+[krName]+[staCD]+[expDlr]+[impDlr]+[balPayments]+[expCnt]+[impCnt])

import pandas as pd 
pd.DataFrame(result).to_csv('%s_수출입총괄(%s)_%s'%(searchBgnDe,searchStatCd,searchStatCd)+'.csv',
        encoding='cp949',header=None, index =False)


