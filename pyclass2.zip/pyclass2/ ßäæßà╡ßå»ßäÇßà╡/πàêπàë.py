import platform
import sys
import konlpy

print("""
system: %s
mac_ver: %s
""" % (
platform.system(),
platform.mac_ver(),
))