import urllib.request
import ssl

from bs4 import BeautifulSoup

import datetime
import math
import pandas as pd
from itertools import count

context = ssl._create_unverified_context()

def get_request_url(url):
    request = urllib.request.Request(url)
    try:
        response = urllib.request.urlopen(request)
        if response.getcode() == 200:
            print("[%s] Url Request Success" % datetime.datetime.now() )
            return response.read().decode("CP949")
    except Exception as e:
        print(e)
        print("[%s] Error for URL : %s" %(datetime.datetime.now(), url))
        return None


if __name__ == "__main__":
    eq_list=[]
    for page in count():
        endpoint = "http://www.weather.go.kr/weather/earthquake_volcano/domesticlist.jsp?"
        params = "startSize=2&endSize=999&x=0&y=0&schOption=T"
        params += "&startTm=" + "2020-01-01"
        params += "&endTm=" + "2021-01-28"
        params +="&pNo=" + str(page+1)   #3페이지만 되는거
        url = endpoint + params
        #print(url)
        response = get_request_url(url)
        soupData = BeautifulSoup(response, 'html.parser')
        #print(soupData.text)
        table=soupData.find('table',{'id':'excel_body'})
        tbody = table.find('tbody')
        trlist=tbody.find_all('tr')
        del trlist[-1]
        isStop = False
        for tr in trlist:
            tr = list(tr.strings)
            if tr[0] == '1':
                isStop = True
            print(tr)
            # 발생시각, 규모, 깊이(km), 최대진도, 위도, 경도, 위치 저장하기
            eq_info={}

            eq_info['timestamp'] = tr[1]
            eq_info['magnitude'] = tr[2]
            eq_info['depth'] = tr[3]
            eq_info['mmi_scale']=tr[4]
            eq_info['lat'] = tr[5]
            eq_info['lon'] = tr[6]
            eq_info['location'] = tr[7]
            eq_list.append(eq_info)
        if isStop == True :   #true면 for tr in trlist 이 for문을 탈출하도록
            break

    df = pd.DataFrame(eq_list)
    df= df[['timestamp', 'magnitude', 'depth', 'mmi_scale', 'lat', 'lon', 'location']]
    df.to_csv('earthquaketest.csv')
    print('완료')




