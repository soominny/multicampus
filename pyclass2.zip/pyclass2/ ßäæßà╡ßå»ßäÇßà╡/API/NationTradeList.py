import urllib.request
import datetime
import pandas as pd
from itertools import count
from config import *
import json
def get_request_url(url):
    request = urllib.request.Request(url)
    try:
        response = urllib.request.urlopen(request)
        if response.getcode() == 200:
            print("[%s] URL Request Success " % datetime.datetime.now())
            return response.read().decode('utf-8')
    except Exception as e: 
        print(e)
        print("[%s] Error for URL : %s" %(datetime.datetime.now(), url))

if __name__ == "__main__":
    searchBgnDe = "201601"
    searchEndDe = "202012"
    searchStatCd = "US"
    numOfRows = "10"
    pageNo = "1"
    endPoint = "http://openapi.customs.go.kr/openapi/service/newTradestatistics/getnationtradeList"
    parameter ="?_type=json&serviceKey=" + serviceKey
    parameter +="&searchBgnDe="+ searchBgnDe
    parameter +="&searchEndDe="+ searchEndDe
    parameter +="&searchStatCd="+searchStatCd
    parameter +="&numOfRows="+numOfRows
    parameter +="&pageNo="+pageNo
    url = endPoint + parameter
    #print(url)
    resultData = get_request_url(url)
    jsonData = json.loads(resultData)
    #print(jsonData)
    result = []
    if jsonData['response']['header']['resultMsg'] == 'NORMAL SERVICE.':
        totalCount = jsonData['response']['body']['totalCount']
        if totalCount > 1:
            for item in jsonData['response']['body']['items']['item']:
                balPayments = item['balPayments']
                expCnt = item['expCnt']
                expDlr = item['expDlr']
                impCnt = item['impCnt']
                impDlr = item['impDlr']
                statCd = item['statCd']
                krName = item['statCdCntnKor1']
                year = item['year']
                print(krName, balPayments, expCnt, year)
                result.append([year] + [krName] + [statCd] + [expDlr] + [impDlr] + [expCnt] + [impCnt] + [balPayments])

    print(result)
    tradeList_table = pd.DataFrame(result, columns=('year', 'krname', 'statCd', 'expDlr',
                                                    'impDlr', 'expCnt', 'impCnt', 'balPayments'))
    tradeList_table.to_csv('수출입테스트자료.csv')
    print('테스트완료')