from flask import Flask, render_template

app = Flask(__name__)
@app.route('/')
def index():
    robots= ['cyber','kings','star']
    return render_template('4.Template_Control.html',robots=robots)

if __name__ == "__main__" :
    app.run(debug=True)