from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def index():
    return '<h1> Goto/robot/name</h1>'

@app.route('/robot/<name>')
def index2(name):
    return render_template('3.TemplateFilter.html', name=name)
    

if __name__ == "__main__":
    app.run()