from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return '<h1> Goto/robot/name</h1>'

@app.route('/robot/<name>')
def index2(name):
    return render_template('2.TemplateVar.html', name=name )

@app.route('/adcrobot/<name>')
def avc_robot_name(name) :
    letter = list(name)
    robot_dic = {'robot_name':name}
    return render_template('2.TemplateVar.html', name=name, mylist=letter, mydic=robot_dic )


if __name__ == "__main__":
    app.run()