from flask import Flask
app = Flask(__name__)

@app.route('/hello')  
def index(): 
    return '<h1>Hello Flask!</h1>'

@app.route('/bye')  
def index2(): 
    return '<h1>bye Flask! </h1>'

@app.route('/model/<name>') # <>을 쓰면 그게 name이라는 변수에 들어감 !  -> 동적 (입력에 따라 변수값이 달라지므로)
def index3(name):
    return f'<h1> This is a page for {name} </h1>'


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True) 
