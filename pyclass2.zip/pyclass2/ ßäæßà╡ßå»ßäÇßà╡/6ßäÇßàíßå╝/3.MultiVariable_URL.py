from flask import Flask, request
app = Flask(__name__)

#ROUTE 정의방법 1

@app.route('/hello')  
def index(): 
    return '<h1>Hello Flask!</h1>'

@app.route('/bye')  
def index2(): 
    return '<h1>bye Flask! </h1>'

@app.route('/search/') #여러개 변수를 넣을때는 변수를 여기에 넣지 않고 따로 넣는게 더 편함        
# http://127.0.0.1:8080/search/?first=park&second=soomin 
def index3():
    first = request.args.get('first')      #나(서버)한테 뭐라고 요청하는것 = request -> 그 요청에 대한 대답하는것 get
    second = request.args.get('second')
    return f'<h1> first:{first}, second:{second} </h1>'


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True) 
