import pymysql
class WordlCityDB:
    def __init__(self):
        pass
    
    #db접속시키기 
    def get_connetxion(self):
        con = pymysql.connect(host='127.0.0.1',user='root',
                                password='1234',db='pythondb',charset='utf8')

        if self.con:
            print("디비 접속 완료")
            print(self.con)
        
    def db_free(self):
        if self.con:
            self.con.close()

    def get_country_list(self,no):
    
        sql= 'SELECT *FROM worldcity ORDER BY no=%s'
        with self.con.cursor() as cursor:
            cursor.execute(sql,no)
        
        row=cursor.fetchone()
        result=[]
     
        result_dic = {}
        result_dic['No']=row[0]
        result_dic['Code'] = row[1]
        result_dic['Name'] = row[2]
        result_dic['GNP'] = row[3]
        result_dic['Population'] = row[4]
    
        
        return result


if __name__ == '__main__':
    db = WordlCityDB()
    for item in db.get_country_list():
        print(item.Name)

    print('='*30)
    item=db.get_country_no(10)
    print(str(item['No'])+item['Name']+str(item['GNP']))

