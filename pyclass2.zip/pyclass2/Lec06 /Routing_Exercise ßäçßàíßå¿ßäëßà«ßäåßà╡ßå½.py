from flask import Flask, request
app = Flask(__name__)


@app.route('/') 
def index(): 
    return '<h1>Welcome Page!</h1>'


@app.route('/convert/<name>') # Fill this in!
def puppylatin(name):
    first = name.split('-')[0]
    second = name.split('-')[1]

    # This function will take in the name passed
    # and then use "puppy-latin" to convert it!

    # HINT: Use indexing and concatenation of strings
    # For Example: "hello"+" world" --> "hello world"
    return f'<h1> {first} {second} </h1>'


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True) 
